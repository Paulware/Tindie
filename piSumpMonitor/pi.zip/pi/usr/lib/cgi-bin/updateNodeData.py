#! /usr/bin/env python

'''
   Format of call:
   http://192.168.0.9/cgi-bin/updateSystem.py?line=lineNumber&column=tag&value=val
   where:
      lineNumber is the number of line you wish to change
      tag = name of the column as specified in line 0 of the file
      value = new value of the column 
'''
import cgi
import cgitb
import Utilities

filename = '/usr/lib/data/nodeData.txt'

def readTags ( filename ):
   f = open (filename, 'r')
   # The first line has the tags or column names
   line = f.readline().rstrip ( ' \n\r' )
   f.close()
   tags = line.split ( ':' )
   return tags
   
def updateValue ( lineNumber, index, value, lines ):
   print 'modify line: ' + str(lineNumber) + 'change element:' + str(index) + ' to: ' + value + '<br>'
   count = 0
   
   f = open ( filename, "w")
   for line in lines:
      if count == lineNumber:
         l = line.rstrip ( ' \n\r' )
         info = l.split ( ':' )
         line = ''
         for i in range (info.__len__()):
            if line != '': 
               line = line + ':'
            if i == index:
               line = line + value
            else:
               line = line + info[i]
         print 'This line will be modified to: <br>' 
         print line + '<br>'
         line = line + '\n' 
         
      f.write ( line )
      count = count + 1
   f.close()
   utilities.showFile ( filename )   

cgitb.enable() 
utilities = Utilities.Utilities()

print "Content-type: text/html\n\n"
print "<html><body>"
print "<h1>Modify a line</h1>"

form = cgi.FieldStorage()
tags = readTags ( filename )
print 'Got tags: '
print tags
print '<br>'
try:
   if True:
      print 'Open: ' + filename + '<br>'
      utilities.showFile ( filename )
      
      f = open (filename,"r")
      lines = f.readlines()
      f.close()
      
      print 'Number of lines: ' + str ( lines.__len__() ) + '<br>'
      
      if lines.__len__() == 0:
         print filename + ' is empty'  
      else: # check lineNumber
         lineNumber = 1 #line 0 contains column header information
         if lineNumber >= lines.__len__(): # There should be 2 lines in the file
            print 'lineNumber too high, cannot find that line in the file'
         else: # Data validation ok
            if "column" in form: 
               columnName = form.getvalue("column")
               count = 0
               index = -1
               for tag in tags:
                  if tag == columnName:
                     index = count                  
                     break
                  count = count + 1
               if index == -1: 
                  print 'Could not find : ' + columnName + ' in line 0 of ' + filename 
               elif "value" not in form:
                  print 'No new value specified for ' + columnName
               else:            
                  updateValue ( lineNumber, index, form.getvalue('value'), lines)
      
            else:
               print 'Please provide a changed value<br>'
      
   
   if False: # redirect back to .py
      print 'redirecting back to .py' + '<br>'
      print '<Script language=\"javascript\">'
      print '   document.location = \"/cgi-bin/editNodeData.py\";'
      print '</Script>'
      
except:
   print 'Error somewhere could not getvalue<BR>'  

print '</body></html>'   
   
