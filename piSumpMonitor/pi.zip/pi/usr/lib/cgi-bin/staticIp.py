#! /usr/bin/env python
import Utilities
utilities = Utilities.Utilities()

print "Content-type: text/html\n\n"
ipAddress = '192.168.0.9'
utilities.toStatic (ipAddress)
utilities.showFile ( '/usr/lib/data/cmdline.txt' )
utilities.showFile ( '/etc/network/interfaces' )

print '<h1>Change will take affect at next reboot</h1>'
print 'Note: If you would like to use a different address than the one listed above, <br>'
print 'place the ipAddress as the only line of the file: /boot/dhcpStatic.txt'
print '<p><input type=button value=\"back\" onclick=\"javascript:window.history.back();\">'