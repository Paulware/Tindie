#! /usr/bin/env python
import Utilities

utilities = Utilities.Utilities()

print "Content-type: text/html\n\n"

utilities.toDHCP ()
utilities.showFile ( '/usr/lib/data/cmdline.txt' )
utilities.showFile ( '/etc/network/interfaces' )

print '<h1>Change will take affect at next reboot</h1>'
print '<p><input type=button value=\"back\" onclick=\"javascript:window.history.back();\">'