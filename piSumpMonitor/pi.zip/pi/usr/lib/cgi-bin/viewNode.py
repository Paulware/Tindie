#! /usr/bin/env python

import cgi
import cgitb
import Utilities
import socket
import time

cgitb.enable()
form = cgi.FieldStorage()
filename = '/usr/lib/data/nodeManifest.txt'
COMMAND_PORT = 4000

class SlaveNode ():
   def __init__(self, ipAddress):
      self.ipAddress = ipAddress
      print 'Created a slave node located at: ' + ipAddress

def getResponse (timeout = 100):
   data = ''
   addr = None
   startTime = time.time()
   while time.time() < startTime + timeout:
      try:
         data, (addr, COMMAND_PORT) = sock.recvfrom( 100 )
         #data = sock.recv (1024)
         if data != '':
            startTime = time.time()
         else:
            time.sleep (0.1)
      except:
         pass      
   return (data,addr)

def getCmdResponse (cmd):
   sock.sendto(cmd, ('192.168.0.255', COMMAND_PORT)) #broadcast the message
   startTime = time.time()
   response = ''
   ipAddress = None
   while time.time() < startTime + 1:
      (r,addr) = getResponse (1)
      if r != cmd: 
         response = r
         ipAddress = addr
         break
   return (response,ipAddress) 
   
def createBroadcastSocket ( ):
   sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM) #UDP
   sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1) #Broadcast
   # localAddress = socket.gethostbyname(socket.gethostname()) 
   #   print 'My ipaddress is: ' + self.localAddress 
   sock.bind ( ("",COMMAND_PORT) ) # now listen at the COMMAND_PORT for responses (use different ports?)
   sock.setblocking (0)
   return sock


def readTags ( filename ):
   f = open (filename, 'r')
   # The first line has the tags or column names
   line = f.readline().rstrip ( ' \n\r' )
   f.close()
   tags = line.split ( ':' )
   return tags
   
def updateValue ( lineNumber, index, value, lines ):
   print 'modify line: ' + str(lineNumber) + 'change element:' + str(index) + ' to: ' + value + '<br>'
   count = 0
   
   f = open ( filename, "w")
   for line in lines:
      if count == lineNumber:
         l = line.rstrip ( ' \n\r' )
         info = l.split ( ':' )
         line = ''
         for i in range (info.__len__()):
            if line != '': 
               line = line + ':'
            if i == index:
               line = line + value
            else:
               line = line + info[i]
         print 'This line will be modified to: <br>' 
         print line + '<br>'
         line = line + '\n' 
         
      f.write ( line )
      count = count + 1
   f.close()
   utilities.showFile ( filename )   

cgitb.enable() 
utilities = Utilities.Utilities()
#sock = createBroadcastSocket()

print "Content-type: text/html\n\n"
print "<html><body>"
print "<h1>Node Manifest</h1>"

if "ipAddress" not in form:
   print 'Error...Missing ipAddress'
else:
   ipAddress = form['ipAddress'].value
   # Process nodeManifest.txt and display pages for each node
   f = open (filename,'r')
   lines = f.readlines()
   f.close()

   print 'Nodes: <hr>'

   for line in lines:
      info = line.rstrip ( ' \n\r' ).split ( ':')
      if info[3] == ipAddress:
         if info[0] == 'Temperature':
            print 'Found Temperature ' + info[1] + ' at: ' + ipAddress  + ' current value: ' + info[2]


print '</body></html>'   
  