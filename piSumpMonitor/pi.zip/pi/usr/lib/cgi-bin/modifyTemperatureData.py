#! /usr/bin/env python
import cgi
import cgitb
import Utilities

cgitb.enable() 
utilities = Utilities.Utilities()
print "Content-type: text/html\n\n"
print '<html><body onload=\"javascript:goBack();\">'
print '<Script language=\"javascript\">'
print '   function goBack() {'
print '     alert ( \'Press enter to return\' ); '
print '     window.history.back();'
print '   }'
print '</Script>'
print "<h1>Temperature Data Modified</h1>"

form = cgi.FieldStorage()
sensor = ''
if "sensor" in form: 
   sensor = form.getvalue("sensor")
   
action = ''   
if "action" in form:
   action = form.getvalue("action")
   
if (action != '') and (sensor != ''):
   filename = '/var/www/dht11/' + sensor + '.log'
   if action == 'half':  # half the data
      utilities.halfTheData (filename)
   elif action == 'purge': # delete all the data
      f = open ( filename, 'w' )
      f.close()
      print filename + ' purged of all data'
   elif action == 'purge30': # delete data older than 30 days
      utilities.purgeData ( filename, 30 )   
      print 'data older than 30 days purged'
   elif action == 'backup': # backup data and start over 
      utilities.backupTemperatureData ( filename )
      print 'data backed up to: ' + filename + '.bak'
else:
   if action == '':
      print 'You must specify an action'
   if sensor == '':
      print 'You must specify a sensor'
   
print '</body ></html>'   
   
