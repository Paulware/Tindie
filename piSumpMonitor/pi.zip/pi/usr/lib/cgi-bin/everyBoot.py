import MailMe

m = MailMe.MailMe()
m.bootupMail()

