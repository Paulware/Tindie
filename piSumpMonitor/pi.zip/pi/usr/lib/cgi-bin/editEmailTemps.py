#! /usr/bin/env python

def showSensor ( name, index ):
   value = '<Select name = \"sensor' + str(index) + '\" onchange=\"javascript:updateValue(' + str(index) + ',\'sensor\',this.value);\">"'
   temps = {'temp1','temp2','temp3','temp4'}
   for temp in temps:
      if temp == name:
         value = value + '<option value=\"' + temp + '\" selected=\"selected\">' + temp + '</option>'
      else:
         value = value + '<option value=\"' + temp + '\">' + temp + '</option>'
   value = value + '</Select>'      
   return value
   
def showSMS ( value, index ):
   msg = '<Select name = \"sms' + str(index) + '\" onchange=\"javascript:updateValue(' + str(index) + ',\'sms\',this.value);\">"'
   options = {'email', 'text'}
   for option in options:
      if option == value:
         msg = msg + '<option value=\"' + option + '\" selected=\"selected\">' + option + '</option>'
      else:
         msg = msg + '<option value=\"' + option + '\">' + option + '</option>'
   msg = msg + '</Select>'      
   return msg

def select (index, name, list):  
   rule = temps[index].rstrip ( ' \n\r')
   info = rule.split(':')
   #print 'info for : ' + name 
   #print info
   selectedValue = ''
   if name == 'above':
     selectedValue = info[1]

   msg = "<Select name=\"" + name + str(index) + "\" onChange=\"javascript:updateValue(" + str(index) + ",\'aboveBelow\',this.value);\">"
   for item in list:
      if selectedValue == item:
         msg = msg + "<option value=\"" + item + "\" selected=\"selected\">" + item + "</option>"
      else:
         msg = msg + "<option value=\"" + item + "\">" + item + "</option>"
      #print '<pre>' + msg + '</pre>'
   msg = msg + "</Select>"
   return msg

print "Content-type: text/html\n\n"
print "<html><body>"
print '<Script language=\"javascript\">'
print '   function updateValue ( lineNumber, tag, value )'
print '   {'
print '       document.location = \"/cgi-bin/updateTempEmail.py?line=\" + lineNumber + \"&\" + tag + \"=\" + value; '
print '   }' 
print '</Script>'
print "<hr>"
print "Add, delete or modify the settings below to configure when to send email when temperature changes"
print "<hr>"

f = open ("/usr/lib/data/postTempEmail.txt","r")
temps = f.readlines()
f.close()
#debug
if True:
   print temps
   print '<hr>'

count = 0
print '<ul>'
for t in temps:
   print '<li>'
   task = t.rstrip( ' \n\r' )
   info = task.split (':')

   if info.__len__() == 6:
      toAdd = info[0]
      temp = info[2]
      print "Send a " + showSMS (info[4],count)  + " message to <input type=\"text\" size=\"25\" onChange=\"javascript:updateValue(" + str(count) + ",\'destination\',this.value);\" name=\"toAdd" + str(count) + "\" value = \"" + toAdd + "\"><br>"
      print ' when ' + showSensor ( info[3], count) + ' sensor is ' + select (count, 'above', ['above','below'] )  
      print " <input type=\"text\" size=\"5\" name=\"temp" + str(count) + "\" value = \"" + temp + "\" onKeyUp=\"javascript:updateValue(" + str(count) + ",\'temperature\',this.value);\"> Degrees Fahrenheit"
      print "<input type=button value=\"delete\" onclick=\"javascript:updateValue (" + str(count) + ",\'delete\', \'delete\');\"><p>"
   count = count + 1
   print '</li>'
print "<li><input type=\"button\" value=\"Add Rule\" onclick=\"updateValue(0,\'add\',\'add\');\"></li>"
print '</ul>'
print '<a href=\"/index.html\">home</a>'
print "</body></html>"
