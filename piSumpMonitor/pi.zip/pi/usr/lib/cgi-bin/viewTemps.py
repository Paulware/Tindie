#! /usr/bin/env python
import Utilities

utilities = Utilities.Utilities()
print "Content-type: text/html\n\n"
print "<h1>Temps: </h1>"
for i in range (4):
   temp = utilities.lastTemp ( '/var/www/dht11/temp' + str(i+1) + '.log') 
   print 'Temp' + str(i+1) + ': ' + str(temp) + '<br>'
