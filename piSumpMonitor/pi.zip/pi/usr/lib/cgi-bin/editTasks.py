#! /usr/bin/env python
print "Content-type: text/html\n\n"
print "<html><body>"

print "<hr>"
print "<h1>One Minute Task Configuration</h1>"
print "This configuration allows you to enable or disable existing tasks"
print "<hr>"
print "<form action=\"/cgi-bin/postTasks.py\" Method=\"Post\">"

f = open ("/usr/lib/data/everyMin.txt","r")
tasks = f.readlines()
f.close()

count = 0
for t in tasks:
   task = t.rstrip( ' \n\r' )
   info = task.split (':')
   if task.find ( 'unchecked') > -1:
      print "<input type=\"checkbox\" name=\"task" + str(count) + "\" unchecked>" + info[1] + "<br>"
   else:
      print "<input type=\"checkbox\" name=\"task" + str(count) + "\" checked>" + info[1] + "<br>"
   count = count + 1

print "<input type=\"submit\" value=\"submit\">"
print "</form>"
print "</body></html>"
