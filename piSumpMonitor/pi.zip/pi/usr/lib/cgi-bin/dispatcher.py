#! /usr/bin/env python
import cgi
import subprocess
print "Content-type: text/html\n\n"

def print_page(title, body):
    # Tell the web server to expect content
    #print "Content-Type: text/html"
    #print

    print """
<html>
<head>
<title>{0}</title>
</head>
<body>
<h1>{0}</h1>
{1}
</body>
</html>
""".format(title, body)

def print_menu():
    # Print a menu
    title = "Raspberry Pi"
    body = """
<p><a href="index.cgi?action=run_command">Run a command</a></p>
<p><a href="index.cgi?action=garage_control">Control the Garage</a></p>
"""
    print_page(title, body)

print_menu()
params = cgi.FieldStorage()
valid = False
action = params.getvalue ('action')
if action:
  print 'Got an action: ' + action
  cmd_list = ['sudo','reboot']
  # cmd_list = "sudo reboot".split()

  try: 
    print (subprocess.Popen (['sudo','reboot'], shell=True))
    print 'cmd finished ok'
  except Exception as ex:
    output = "Error running command:" + ex
    print output  
else:
  print 'Got no action execute1, sudo reboot'
  try:
     print (subprocess.check_output ( ['sudo', 'reboot']))
  except Exception as ex:
     print 'Could not do it ' 
     print  ex
  print 'done executing cmd'


