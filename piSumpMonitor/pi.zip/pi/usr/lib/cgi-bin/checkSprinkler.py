import Utilities

gpios = ['gpio17', 'gpio18', 'gpio21', 'gpio22', 'gpio23', 'gpio24', 'gpio25', 'gpio4']

utilities = Utilities.Utilities()
f = open ( '/usr/lib/data/sprinklerData.txt', 'r')
sprinklers = f.readlines()
f.close()

hourMin = utilities.getHourMinute()
info = hourMin.split ( ':' )
print 'The time is: ' + info[0] + ':' + info[1]
currentHour = info[0]
currentMinute = info[1]

first = True
count = 0
for sprinkler in sprinklers:
   if first:
      pass # skip header
   else:
      info = sprinkler.split (':') 
      if (info[1] == currentHour) and (info[2] == currentMinute):
         print 'Start/Energize relay ' + str (count)
         utilities.runProcess ('/usr/lib/cgi-bin/setRelay ' + gpios[count] + ' 1')
      elif (info[3] == currentHour) and (info[4] == currentMinute):
         print 'End/DeEnergize relay ' + str (count)
         utilities.runProcess ('/usr/lib/cgi-bin/setRelay ' + gpios[count] + ' 0')
         
      count = count + 1   
      
   first = False
   
print 'Done in checkSprinkler.py today is: ' + utilities.dayOfWeek()