import RPi.GPIO as GPIO

def getLastTemp (filename):
   # Get last temperature readings from log files
   lastTemp = 0.0
   try:
      f = open (filename)
      lines = f.readlines ()
      f.close()
      for line in lines:
         info = line.split ( ',' )
         if info.__len__() == 3: 
            lastTemp = float(info[2])
      print 'Got a lastTemp : ' + str(lastTemp)
   except:
      pass

   return lastTemp

# Read in last relay values 
f = open ( '/usr/lib/data/lastRelay.txt', 'r' )
lines = f.readlines () 
f.close()
offOn = []
for i in range (4):
   try:
      l = lines[i]
      line = l.rstrip ( ' \n\r' )
   except:
      line = ''

   status = 'unknown'
   if line.lower() == 'energized':
      status = 'energized'
   elif line.lower() == 'deenergized':
      status = 'deenergized'
   offOn.append (status)   

f = open ( '/usr/lib/data/postTempData.txt' )
lines = f.readlines()
f.close()

# Get last temperature readings from log files
temps = []
temps.append ( getLastTemp ( '/var/www/dht11/temp1.log') )
temps.append ( getLastTemp ( '/var/www/dht11/temp2.log') )
temps.append ( getLastTemp ( '/var/www/dht11/temp3.log') )

count = 0
pins = [4,17,18,27]
GPIO.setmode (GPIO.BCM)
for pin in pins:
   GPIO.setup (pin,GPIO.OUT)

for line in lines: 
   info = line.rstrip(' \n\r').split(':')
   if info[0] != 'None':
      print info
      relay = int(info[0]) - 1
      energized = info[1]
      above = info[2]
      temp = int(info[3])
      sensor = int(info[4]) - 1
      if above == 'above':
         if temps[sensor] > temp:
            if energized == 'energized':
               print 'Energize relay: ' + str (relay)
               GPIO.output (pins[relay], True)      
               offOn[relay] = 'energized'                                       
            else:
               print 'Deenergize relay: ' + str (relay)         
               GPIO.output (pins[relay], False)                                             
               offOn[relay] = 'deenergized'                                       
      else: #below
         if temps[sensor] < temp:
            if energized == 'energized':
               print 'Energize relay: ' + str (relay)
               GPIO.output (pins[relay], True)                                             
               offOn[relay] = 'energized'                                       
            else:
               print 'Deenergize relay: ' + str (relay)         
               GPIO.output (pins[relay], False)     
               offOn[relay] = 'deenergized'                                       


# Create output page 
f = open ('/var/www/tempRelay/index.html', 'w' )
f.write ( '<html><head><title>Temp relay status</title></head>\n' )
f.write ( '<body>\n' )
f.write ( '<h1>Sensors</h1><hr>\n')
f.write ( '<Table border=2px>' )
f.write ( '<tr><th>Sensor</th><th>Temperature</th></tr>\n' )
for i in range (3):
   f.write ( '<tr><td>' + str(i+1) + '</td><td>' + str (temps[i] ) + ' F</td></tr>\n' )
f.write ( '</Table>\n' )

f.write ( '<h1>Relays</h1><hr>\n')
f.write ( '<Table border=2px>' )
f.write ( '<tr><th>Relay</th><th>Energized/Deenergized</th></tr>\n' )
for i in range (4):
   f.write ( '<tr><td>' + str(i+1) + '</td><td>' + str (offOn[i] ) + '</td></tr>\n' )
f.write ( '</Table>\n' )

f.write ( '</body></html>\n' )
f.close()                                        
  
