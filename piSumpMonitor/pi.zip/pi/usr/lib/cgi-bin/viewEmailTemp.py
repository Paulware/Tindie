#! /usr/bin/env python
print "Content-type: text/html\n\n"
print "<html><body>"

f = open ("/usr/lib/data/postTempEmail.txt","r")
lines = f.readlines()
f.close()
print lines
print 'read : ' + str ( lines.__len__()) + ' lines'
for i in range(lines.__len__()):
   print str(i) + ':' + lines[i]

toAdd = "user@hotmail.com"
try: 
  
  username = lines[0]
except:
  pass 

password = "password"
try: 
  password = lines[1]
except:
  pass

toAddress = "ToAddress@something.com"
try: 
  toAddress = lines[2]
except:
  pass

print "<hr>"
print "<h1>Email Configuration</h1>"
print "This data is used to send you an email whenever the pi\'s ip Address changes<br>"
print "Each minute, the ip address is checked, if a change is detected the toAddress below will receive an email message<br>"
print "To enable this feature, you will need an account at gmail to send the message from"
print "<hr>"
print "<form action=\"/cgi-bin/postMailData.py\" Method=\"Post\">"
print "Gmail Username:<input type=\"text\" size=\"20\" name=\"username\" value=\"" + username + "\">@gmail.com<br>"
print "Gmail Password:<input type=\"text\" size=\"20\" name=\"password\" value=\"" + password + "\"><br>"
print "ToAddress:<input type=\"text\" size=\"30\" name=\"toAddress\" value=\"" + toAddress + "\"><br>"
print "<hr>"
print "<input type=\"submit\" value=\"submit\">"
print "</form>"
print "</body></html>"