#! /usr/bin/env python
import cgi
import cgitb
'''
import serial                                                                   
serialport = serial.Serial("/dev/ttyAMA0", 115200, timeout=0.5)                   
'''
cgitb.enable()

print "Content-type: text/html\n\n"
print "<h1>Hello</h1>"
form = cgi.FieldStorage()
if "command" not in form:
   print "<h1>The text input box was empty.</h1>"
else:
   text=form["command"].value
   print "<h1>Text sent over serial: </h1>"
   '''
   line =  cgi.escape(text)
   serialport.write(line)
   print 'Sent: ' + line                                                  

   #f = open ("newData.txt","a")
   #f.write ( text + '\n' )
   #f.close()
   '''