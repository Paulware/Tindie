import RPi.GPIO as GPIO
f = open ( '/usr/lib/data/postTempData.txt' )
lines = f.readlines()
f.close()

# Get last temperature readings from log files
temps = []
temps.append (5)
temps.append (15)
temps.append (101)

count = 0
GPIO.setmode (GPIO.BCM)

GPIO.setup (22,GPIO.IN)
value = GPIO.input (22 )
print 'Read a value: ' + str (value)