import MailMe

m = MailMe.MailMe()
f = open ( '/usr/lib/data/postTempEmail.txt', 'r' )
lines = f.readlines()
f.close()

''' 
   If temperature above or below a limit send an email
   format of data
   email address:above/below:temperature
'''
outputLines = []
for line in lines: 
   info = line.rstrip(' \n\r').split(':')
   if info[0] != 'None':
      # read the last sensor value
      sensor = info[3]
      emailText = info[4]
      toAddress = info[0].replace ( ' ','' )
      lastTemp = m.getLastTemp('/var/www/dht11/' + sensor + '.log')
      print info
      if info[1] == 'above':
         if lastTemp > int(info[2]):
             if str(lastTemp) == info[5]:
                print 'No email sent because lastemp sent is identical to: ' + info[5]
             else:
                info[5] = str(lastTemp)
                
                subject = sensor + ' ' + info[5]
                body = sensor + ' is above ' + info[2]
                if emailText == 'email':
                   m.sendMail (subject, body ) 
                else:
                   m.sendText (subject, body, toAddress) 
                
      else: #below
         if lastTemp < int (info[2]):
             if str(lastTemp) == info[5]:
                print 'No email sent because lastTemp sent is identical to: ' + info[5]
             else:
                info[5] = str(lastTemp)
                subject = sensor + ' ' + info[5] 
                body = sensor + ' is below ' + info[2]
                if emailText == 'email':
                   print 'send email to: ' + toAddress + ' because ' + sensor + ' < ' + info [2]
                   m.sendMail ( subject, body)
                else:
                   print 'send text to: ' + toAddress + ' because ' + sensor + ' < ' + info [2]
                   m.sendText ( subject, body, toAddress )
                
      line = info[0] + ':' + info[1] + ':' + info[2] + ':' + info[3] + ':' + info[4] + ':' + info[5]
      outputLines.append ( line )
   
f = open ( '/usr/lib/data/postTempEmail.txt', 'w' )
for line in outputLines:
   f.write ( line + '\n')
f.close()
