import os 
import smtplib 
import socket 
from time import localtime, strftime 
import re 
import Utilities
class MailMe ():
   def __init__(self):
      f = open ("/usr/lib/data/postMailData.txt","r")
      lines = f.readlines()
      f.close()

      print 'read lines: '
      print lines

      try:
         self.username = lines[0].rstrip('\n\r ')
      except:
         self.username = "user"

      try:
         self.password = lines[1].rstrip('\n\r ')
      except:
         self.password = "password"

      try:
         self.toAddress = lines[2].rstrip('\n\r ')
      except:
         self.toAddress = "ToAddress@something.com"
         
      try:
         self.phoneProvider = lines[3].rstrip ( '\n\r ')
      except:
         self.phoneProvider = 'phoneProvider'

      try:
         self.lastIpAddress = lines[4].rstrip('\n\r ')
      except:
         self.lastIpAddress = 'last.ip.addr.ess'

      print 'Got username: ' + self.username
      print 'Got password: ' + self.password
      print 'Got toAddress: ' + self.toAddress
      print 'Got lastIpAddress: ' + self.lastIpAddress
      
      self.utilities = Utilities.Utilities()

   def getCurrTime(self):
      currTime = strftime ( "%Y-%m-%d %H:%M:%S", localtime())
      return currTime

   def getLocalAddress (self):
      ipAddress = ''
      try:
         s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
         s.connect ( ('gmail.com', 80))
         ipAddress = s.getsockname()[0]
         s.close()
      except:
         pass
      return ipAddress

   def getIpAddress(self):
      ipAddress = ''
      try: 
         os.popen ( 'rm -f /root/index.html')
         os.popen ( 'wget -4 http://checkip.dyndns.org')
         f = open ( '/root/index.html','r' )
         line = f.read()
         f.close()
         ipAddress = re.findall (r'\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b',line)[0]
      except:
         pass      
      return ipAddress

   def sendText (self, subject, body, cellNumber):   
      ok = True
      fromAddr = self.username + '@gmail.com'
      smtpPass = self.password
      toAddresses = []
      if self.phoneProvider == 'Alltel': 
         toAddresses.append ( cellNumber + '@message.alltel.com' )
      elif self.phoneProvider == 'AT&T':
         toAddresses.append ( cellNumber + '@txt.att.net' )
         toAddresses.append ( cellNumber + '@mms.att.net' )
         toAddresses.append ( cellNumber + '@cingularm2.com' )
      elif self.phoneProvider == 'Boost Mobile':
         toAddresses.append ( cellNumber + '@myboostmobile.com' )
      elif self.phoneProvider == 'Sprint Nextel':
         toAddresses.append ( cellNumber + '@messaging.nextel.com' )
      elif self.phoneProvider == 'Sprint PCS':
         toAddresses.append ( cellNumber + '@messaging.sprintpcs.com' )
         toAddresses.append ( cellNumber + '@pm.sprint.com' )
      elif self.phoneProvider == 'T-Mobile':
         toAddresses.append ( cellNumber + '@tmomail.net' )
      elif self.phoneProvider == 'USCellular':
         toAddresses.append ( cellNumber + '@email.uscc.net' )
         toAddresses.append ( cellNumber + '@mms.uscc.net' )
      elif self.phoneProvider == 'Verizon':
         toAddresses.append ( cellNumber + '@vtext.com'  )
         toAddresses.append ( cellNumber + '@vzwpix.com' )
      elif self.phoneProvider == 'Virgin Mobile':
         toAddresses.append ( cellNumber + '@vmobl.com' )

      for toAdd in toAddresses:          
         #toAdd = self.cellNumber + '@' + self.phoneProvider
         header = 'To: ' + toAdd + '\nFrom: ' + fromAddr + '\nSubject: ' + subject
         smtpUser = self.username
         try:
            s = smtplib.SMTP ('smtp.gmail.com', 587)
            s.ehlo()
            s.starttls()
            s.ehlo()
            s.login (smtpUser, smtpPass)
            print 'Send ' + body + ' to: ' + toAdd
            s.sendmail ( smtpUser, toAdd, header + '\n' + body)
            s.quit()
            print body + ' sent to : ' + toAdd
         except:
            print 'Could not send the text\n password: ' + smtpPass + '\nheader: ' + header + ' body: ' + body 
            ok = False

      return ok
      
   def sendMail (self, subject, body ):
      ok = True
      fromAddr = self.username + '@gmail.com'
      smtpPass = self.password
      toAdd = self.toAddress
      header = 'To: ' + toAdd + '\nFrom: ' + fromAddr + '\nSubject: ' + subject
      smtpUser = self.username
      try:
         s = smtplib.SMTP ('smtp.gmail.com', 587)
         s.ehlo()
         s.starttls()
         s.ehlo()
         print 'user: ' + smtpUser + ' password: ' + smtpPass
         s.login (smtpUser, smtpPass)
         s.sendmail ( smtpUser, toAdd, header + '\n' + body)
         s.quit()
         print 'email sent'
      except:
         print 'Could not send the email, fromAddr: ' + fromAddr + '\nsmtpPass: ' + smtpPass + '\ntoAdd: ' + toAdd + '\nheader: ' + header + '\nbody: ' + body 
         ok = False

      return ok

   def statusMail(self):
      subject = 'Daily Status'
      currentIp = self.getIpAddress()

      body = self.getCurrTime() + '\nHello from pi at: ' + currentIp + '\nMy local address is: ' + self.getLocalAddress() 
      body = body + ' The current temperature is: ' + str ( self.utilities.lastTemp ('/var/www/dht11/temp1.log') ) 
      body = body + '\n'
      if not self.sendMail(subject,body):
         print 'Could not send the mail'

   def bootupMail(self):
      subject = 'Booting Up'
      currentIp = self.getIpAddress()

      body = self.getCurrTime() + '\nHello from pi at: ' + currentIp + '\nMy local address is: ' + self.getLocalAddress() 
      body = body + ' The current temperature is: ' + str ( self.utilities.lastTemp ('/var/www/dht11/temp1.log') ) 
      body = body + '\n'
      if self.sendMail(subject,body):
         print 'bootup mail sent'
      else:
         print 'Could not send bootup mail'

   def wakeupEmail (self, force=False):
      subject = 'IP Address change'
      currentIp = self.getIpAddress()
      
      if currentIp != '':
         if (self.lastIpAddress == currentIp) and not force: 
            print 'No change to ip address '
         else:
            body = self.getCurrTime() + '\nHello from pi at: ' + currentIp + '\nMy local address is: ' + self.getLocalAddress() 
            body = body + '\nMy previous ip address was: ' + self.lastIpAddress + ', and my current ip address is:' + currentIp + '.'
            body = body + '\nCurrent Temperature: ' + str ( self.utilities.lastTemp ('/var/www/dht11/temp1.log') ) 
            self.sendMail(subject,body)

            # update the mail data 
            f = open ("/usr/lib/data/postMailData.txt","w")
            f.write (self.username + '\n')
            f.write (self.password + '\n')
            f.write (self.toAddress + '\n')
            f.write (self.phoneProvider + '\n' )
            f.write (currentIp + '\n' )
            f.write (self.getCurrTime() + '\n')
            f.close()
