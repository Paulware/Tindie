import socket
import time

COMMAND_PORT = 4000
TYPENAME = 'Temperature'
NODENAME = 'Living Room'
VALUE = 62.6

def localAddress():
   return socket.gethostbyname(socket.gethostname()) 

def getIpAddress():
   os.popen ( 'cd /home/pi' )
   os.popen ( 'rm -f index.html')
   os.popen ( 'wget -4 http://checkip.dyndns.org')
   try:
      f = open ( 'index.html','r' )
      line = f.read()
      f.close()
      ipAddress = re.findall (r'\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b',line)[0]
   except:
      ipAddress = ''
   return ipAddress
  
def createBroadcastSocket ( ):
   sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM) #UDP
   sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1) #Broadcast
   # localAddress = socket.gethostbyname(socket.gethostname()) 
   #   print 'My ipaddress is: ' + self.localAddress 
   sock.bind ( ("",COMMAND_PORT) ) # now listen at the COMMAND_PORT for responses (use different ports?)
   sock.setblocking (1)
   return sock
   
def getResponse (timeout = 100):
   data = ''
   startTime = time.time()
   while time.time() < startTime + timeout:
      data = sock.recv (1024)
      if data != '':
         break
      else:
         time.sleep (0.1)
   return data

sock = createBroadcastSocket()
data = getResponse () 
print 'got : ' + data 
if data == 'nodesReport':
   msg = TYPENAME + ':' + NODENAME + ':' + str (VALUE)
   sock.sendto ( msg, ('192.168.0.255', COMMAND_PORT) ) 
