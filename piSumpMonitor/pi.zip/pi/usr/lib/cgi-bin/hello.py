#! /usr/bin/env python
import cgi
import cgitb
cgitb.enable()

print "Content-type: text/html\n\n"
print '<meta http-equiv=\"Pragma\" content=\"no-cache\" />'

print "<h1>Hellod</h1>"

form = cgi.FieldStorage()
try:
   line = int (form.getvalue("line"))
   print 'delete line: ' + str(line) 
except:
   print 'Could not getvalue (name)<BR>'   

try:
   if "name" not in form or "addr" not in form:
      print "<H1>Error</H1>"
      print "Please fill in the name and addr fields."
   else:
      print "<p>name:", form["name"].value

except:
   print 'Could not check name or addr in form'
   
   
