#! /usr/bin/env python   
def showNodeTypes ( value ):
   msg = '<Select onchange=\"javascript:updateValue(\'nodeType\',this.value);\">"'
   options = {'Temperature', '8ChannelRelay', 'RCTank'}
   for option in options:
      if option == value:
         msg = msg + '<option value=\"' + option + '\" selected=\"selected\">' + option + '</option>'
      else:
         msg = msg + '<option value=\"' + option + '\">' + option + '</option>'
   msg = msg + '</Select>'      
   return msg

print "Content-type: text/html\n\n"
print "<html><body>"
print '<Script language=\"javascript\">'
print '   function updateValue ( tag, value )'
print '   {'
print '       document.location = \"/cgi-bin/updateNodeData.py?column=\" + tag + \"&value=\" + value; '
print '   }' 
print '</Script>'
print "<hr>"
print "Modify the type or name below to configure the raspberry pi slave node"
print "<hr>"

f = open ("/usr/lib/data/nodeData.txt","r")
node = f.readlines() # line[0] is column names, line[1] is values
f.close()

# format of node data: 
# NodeType:NodeName:Value

count = 0
print '<ul>'
t = node[1]
print '<li>'
task = t.rstrip( ' \n\r' )
info = task.split (':')
nodeType = info[0]
nodeName = info[1]

print "This node is a " + showNodeTypes (nodeType)  + " named "
print "<input type=\"text\" size=\"25\" onChange=\"javascript:updateValue(\'nodeName\',this.value);\" value = \"" + nodeName + "\"><br>"
print '</li>'
print '</ul>'
print '<a href=\"/index.html\">home</a>'
print "</body></html>"