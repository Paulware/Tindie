#! /usr/bin/env python
import cgi
import cgitb
cgitb.enable()

filename = 'postTempEmail.txt'

print "Content-type: text/html\n\n"
print "<h2>Posting to " + filename + "</h1>"
form = cgi.FieldStorage()
print "Text from text input box:<br>"

f = open ("/usr/lib/data/" + filename,"w")
for i in range(2):
   sensor = form["sensor" + str(i)].value
   print 'got a sensor: ' + sensor
   toAdd = form["toAdd" + str(i)].value
   print ( 'Send email to ' + toAdd + ' ' )
   aboveBelow = form["above" + str(i)].value
   print ( ' when temperatures ' + aboveBelow )
   temp = form["temp" + str(i)].value
   print ( ' ' + temp + ' degrees Fahrenheit <br>')
   f.write ( toAdd + ':' + aboveBelow + ':' + temp + ':' + sensor + '\n')
f.close()

print "Data successfully written to /usr/lib/data/" + filename + "<br>"
print "<a href=\"/dhtRelay/index.html\">home</a>"
print "<script>\n"
print "  // window.location.href = \"/index.html\";\n"
print "</script>\n"
