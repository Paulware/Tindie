#! /usr/bin/env python
import cgi
import cgitb
cgitb.enable()

print "Content-type: text/html\n\n"
print "<h2>Posting to postTempData.txt</h1>"
form = cgi.FieldStorage()
rules = []

for i in range(8):
   try:
      rule = form["relay" + str(i)].value + ':' + form["energized" + str(i)].value + ':' + \
             form["above" + str(i)].value + ':' + form["temp" + str(i)].value + ':' + form["sensor" + str(i)].value
   except:
      rule = ''
   rules.append (rule)

print 'rules: ' 
print rules

print "Text from text input box:<hr>"

f = open ("/usr/lib/data/postTempData.txt","w")
for i in range(8):
   f.write ( rules[i] + '\n' )
   print ( rules[i] + '<br>\n' )
f.close()
print "Data successfully written to <br>"
print "<a href=\"/dhtRelay/index.html\">home</a>"
print "<script>\n"
print "  // window.location.href = \"/index.html\";\n"
print "</script>\n"
