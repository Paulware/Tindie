import Utilities
utilities = Utilities.Utilities()

rebootRequired = False
if utilities.filesDifferent ( '/usr/lib/data/dhcpStatic.txt','/boot/dhcpStatic.txt' ):   
   # /boot/dhcpStatic.txt is only written to by the user to control ip Address
   try:
      f = open ( '/boot/dhcpStatic.txt', 'r' )
      dhcpStatic = f.readline().rstrip ( ' \n\r' ) # get 'dhcp' or 'ip.addr.e.ss'
      f.close ()
      
      if dhcpStatic.upper() == 'DHCP':
         print 'Changing files to dhcp because dhcpStatic.txt changed'
         utilities.toDHCP ()    
      else:
         print 'Changing files to static because dhcpStatic.txt changed'
         utilities.toStatic(dhcpStatic)        
   except:
      print 'dhcpStatic.txt change failed for some unknown reason'
   
   utilities.runProcess ( 'sudo cp /boot/dhcpStatic.txt /usr/lib/data/dhcpStatic.txt' )
   rebootRequired = True
   print 'cmdline.txt files do not match, copy over'

if utilities.filesDifferent ( '/usr/lib/data/cmdline.txt','/boot/cmdline.txt' ):
   utilities.runProcess ( 'sudo cp /usr/lib/data/cmdline.txt /boot/cmdline.txt' )
   rebootRequired = True
   print 'cmdline.txt files do not match, copy over'
   
if rebootRequired:
   print 'Rebooting now'
   utilities.runProcess ( 'sudo shutdown -r now' )
else:
   print 'Files match, no reboot required'
