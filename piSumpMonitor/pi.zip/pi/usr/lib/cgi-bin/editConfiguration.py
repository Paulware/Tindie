#! /usr/bin/env python
import Utilities
utilities = Utilities.Utilities()

def showProviders (phoneProvider):
   msg = '<Select name=\"phoneProvider\">' 
   providers = {'Alltel', 'AT&T', 'Boost Mobile', 'Sprint Nextel', 'Sprint PCS', 'T-Mobile', 'USCellular', 'Verizon', 'Virgin Mobile'}
   for provider in providers:
      if provider == phoneProvider:
         msg = msg + '<option value=\"' + provider + '\" selected=\"selected\">'
      else:
         msg = msg + '<option value=\"' + provider + '\">'
      msg = msg + provider + '</option>'   
   msg = msg + '</Select>'
   return msg
      
print "Content-type: text/html\n\n"
print "<html><body>"

print utilities.javascriptUpdateValue('updateWpaSupplicantData.py' )

f = open ("/usr/lib/data/postMailData.txt","r")
lines = f.readlines()
f.close()
'''
print lines
print 'read : ' + str ( lines.__len__()) + ' lines'
for i in range(lines.__len__()):
   print str(i) + ':' + lines[i]
'''
username = "user"
try: 
  username = lines[0]
except:
  pass 

password = "password"
try: 
  password = lines[1]
except:
  pass

toAddress = "ToAddress@something.com"
try: 
  toAddress = lines[2]
except:
  pass
    
phoneProvider = 'phoneProvider'
try:
  phoneProvider = lines[3].rstrip ( '\n\r ')
except:
  pass  
  
print "<Script language=\"javascript\">"
print "   function runCgi (filename) {" 
print "      document.location = \"/cgi-bin/\" + filename;"
print "   }"
print "</Script>"
print ""  
print "<hr>"
print "<h1>Email Configuration</h1>"
print "This data is used to send you an email whenever the pi\'s ip Address changes<br>"
print "Each minute, the ip address is checked, if a change is detected the toAddress below will receive an email message<br>"
print "To enable this feature, you will need an account at gmail to send the message from"
print "<form action=\"/cgi-bin/postMailData.py\" Method=\"Post\">"
print "Gmail Username:<input type=\"text\" size=\"20\" name=\"username\" value=\"" + username + "\">@gmail.com<br>"
print "<hr>"
print "Gmail Password:<input type=\"text\" size=\"20\" name=\"password\" value=\"" + password + "\"><br>"
print "ToAddress:<input type=\"text\" size=\"30\" name=\"toAddress\" value=\"" + toAddress + "\"><br>"
print 'Cell phone provider:' + showProviders(phoneProvider) + '<br>'
print "<hr>"
print "<input type=\"submit\" value=\"submit\">"
print "</form>"
print "<hr>"
print "<h1>Wifi Configuration</h1>"
print "<hr>"
print "Enter the ssid of your wireless router and the network password<br>"
print "Each data item will update when its changes and you mouse click off the item<br>"
print "This will update the /etc/wpa_supplicant/wpa_supplicant.conf file<br>"
print "<hr>"

f = open ("/usr/lib/data/wpaSupplicant.txt","r")
lines = f.readlines() # line[0] is column names, line[1] is values
f.close()

print '<table border=2px>'
info = lines[0].rstrip(' \n\r').split ( ':' )
print '<tr><td>' + info[0] + '</td><td>' + info[1] + '</td></tr>'      

info = lines[1].rstrip (' \n\r').split ( ':' )
print '<tr><td>' 
print utilities.showInput ( 'ssid', info[0], 1) 
print '</td><td>'
print utilities.showInput ( 'psk', info[1], 1)
print '</td></tr></table>'

print "<hr>"
print "<h1>Ip Address Configuration</h1>"
print "Set <input type=button value=\"Static\" onclick=\"runCgi('staticIp.py');\"> Or <input type=button value=\"Dynamic\" onclick=\"runCgi('dynamicIp.py');\"> Ip Allocations<br>"
print '<a href=\"/index.html\">home</a>'

print "</body></html>"
