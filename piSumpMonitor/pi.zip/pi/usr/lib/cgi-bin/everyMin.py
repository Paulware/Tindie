import os
#import subprocess
f = open ( '/usr/lib/data/everyMin.txt' )
lines = f.readlines()
f.close()
print 'Done in everyMin.py'

for line in lines: 
   info = line.rstrip(' \n\r').split(':')
   if info[0] == 'checked':
      print 'Execute: ' + info[2]
      os.popen ( info[2] )
      #process = subprocess.Popen (info[2])
      #while process.poll() is None:
      #   time.sleep(1)
      print 'Done executing: ' + info[2]
   else:
      print 'Ignore: ' + info[2]

