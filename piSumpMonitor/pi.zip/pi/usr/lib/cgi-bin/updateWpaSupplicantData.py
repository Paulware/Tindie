#! /usr/bin/env python
import Utilities

def writeWpa_Supplicant (filename, ssid, psk ):
   f = open ( filename, 'w')
   f.write ( 'ctrl_interface=DIR=/var/run/wpa_supplicant GROUP=netdev\n' )
   f.write ( 'update_config=1\n\n')
   f.write ( 'network={\n' )
   f.write ( '\tssid=\"' + ssid + '\"\n' )
   f.write ( '\tpsk=\"' + psk + '\"\n' )
   f.write ( '\tproto=RSN\n' )
   f.write ( '\tkey_mgmt=WPA-PSK\n' )
   f.write ( '\tpairwise=CCMP\n' )
   f.write ( '\tauth_alg=OPEN\n' )
   f.write ( '}\n' )
   f.close ()


utilities = Utilities.Utilities()
utilities.updateFormValues ('/usr/lib/data/wpaSupplicant.txt')

f = open ( '/usr/lib/data/wpaSupplicant.txt', 'r' )
lines = f.readlines ()
f.close ()
info = lines[1].rstrip ( ' \n\r').split ( ':' )

f = open ( '/usr/lib/data/wpa_supplicant.conf', 'r')
data = f.read()
f.close()

filename = '/etc/wpa_supplicant/wpa_supplicant.conf'
writeWpa_Supplicant ( filename, info[0], info[1] )

'''
# cause a reboot on next boot
f = open ( '/usr/lib/data/dhcpStatic.txt', 'w' )
f.write ( 'dhcp') #wifi that is static doesn't make much sense
f.close ()      
'''

#utilities.runProcess ( 'cp /usr/lib/data/wpa_supplicant.conf /etc/wpa_supplicant/wpa_supplicant.conf' )
utilities.showFile ( filename )
#print 'size of wlan0: ' + str ( utilities.fileSize ( '/etc/wpa_supplicant/wpa_supplicant.wlan0') ) + ' .conf: ' + str ( utilities.fileSize ( filename ) )

if True: # redirect back to .py
   print 'redirecting back to .py' + '<br>'
   print '<Script language=\"javascript\">'
   print '   window.history.back();'
   print '</Script>'
     
print '</body></html>'   
   
