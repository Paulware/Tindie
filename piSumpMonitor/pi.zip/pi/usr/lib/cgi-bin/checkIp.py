import MailMe
m = MailMe.MailMe()
m.wakeupEmail ()  
