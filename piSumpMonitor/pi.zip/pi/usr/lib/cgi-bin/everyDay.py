import MailMe
import Utilities

m = MailMe.MailMe()
m.statusMail()
utilities = Utilities.Utilities()

f = open ( '/usr/lib/data/journal.txt', 'a')
f.write ( 'Sent status mail ' + utilities.timeStamp() + '\n' )
f.close()

