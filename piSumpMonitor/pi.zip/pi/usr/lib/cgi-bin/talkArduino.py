#!/usr/bin/python                                                               
                                                                                
# code from                                                                     
# http://shallowsky.com/blog/2011/Oct/16/                                       
                                                                                
import serial                                                                   
import time                                                                     
import select                                                                   
import sys                                                                      
                                                                                
serialport = serial.Serial("/dev/ttyAMA0", 115200, timeout=0.5)                   
                                                                                
while True:                                                                     
    # Check whether the user has typed anything (timeout of .2 sec):            
    inp, outp, err = select.select([sys.stdin, serialport], [], [], .2)         
                                                                                
    # If the user has typed anything, send it to the Arduino:                   
    if sys.stdin in inp :                                                       
        line = sys.stdin.readline() 
        serialport.write(line)                                                 
                                                                                
    # If the Arduino has printed anything, display it:                          
    if serialport in inp :                                                      
        line = serialport.readline().strip()                                    
        print "Arduino:", line
