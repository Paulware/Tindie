#! /usr/bin/env python

'''
   Format of call:
   http://192.168.0.9/cgi-bin/updateSprinklerData.py?line=lineNumber&column=columnName&value=val
   where:
      lineNumber is the number of line you wish to change
      columnName = name of the column as specified in line 0 of the file
      val = new value of the column 
'''
import cgi
import cgitb
import Utilities

filename = '/usr/lib/data/sprinklerData.txt'


cgitb.enable() 
utilities = Utilities.Utilities()

print "Content-type: text/html\n\n"
print "<html><body>"
print "<h1>Modify a line</h1>"

form = cgi.FieldStorage()
tags = utilities.readTags ( filename )
print 'Got tags: '
print tags
print '<br>'
try:
   if True:
      print 'Open: ' + filename + '<br>'
      # utilities.showFile ( filename )
      
      f = open (filename,"r")
      lines = f.readlines()
      f.close()
      
      print 'Number of lines: ' + str ( lines.__len__() ) + '<br>'
      
      if lines.__len__() == 0:
         print filename + ' is empty'  
      else: # check lineNumber
         lineNumber = int ( form.getvalue ( 'line' ) )
         if "column" in form: 
            columnName = form.getvalue("column")
            count = 0
            index = -1
            for tag in tags:
               if tag == columnName:
                  index = count                  
                  print '<br>Matched ' + tag + ' on index: ' + str (index) + '<br>'
                  break
               count = count + 1
            if index == -1: 
               print 'Could not find : ' + columnName + ' in line 0 of ' + filename 
            elif "value" not in form:
               print 'No new value specified for ' + columnName
            else:            
               utilities.updateValue ( filename, lineNumber, index, form.getvalue('value'), lines)      
               #utilities.showFile ( filename )   
         else:
            print 'Please provide a changed value<br>'
      
   
   if True: # redirect back to .py
      print 'redirecting back to .py' + '<br>'
      print '<Script language=\"javascript\">'
      print '   document.location = \"/cgi-bin/editSprinklerData.py\";'
      print '</Script>'
      
except:
   print 'Error somewhere could not getvalue<BR>'  

print '</body></html>'   
   
