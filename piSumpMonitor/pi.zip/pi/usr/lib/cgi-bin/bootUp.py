import Utilities
import os
import time

utilities = Utilities.Utilities()
# /boot/dhcpStatic.txt exists, a reboot is required
rebootRequired = False
if utilities.fileSize ( '/boot/dhcpStatic.txt' ) > 0:
   print '/boot/dhcpStatic.txt exists'
   rebootRequired = True
   f = open ( '/boot/dhcpStatic.txt', 'r' )
   try:
      dhcpStatic = f.readline().rstrip ( ' \n\r' )
   except:
      pass
   f.close ()
   # /etc/rc.local will delete this file
   
if utilities.fileSize ( '/usr/lib/data/dhcpStatic.txt' ) > 0:
   print '/usr/lib/data/dhcpStatic.txt exists'
   rebootRequired = True
   f = open ( '/usr/lib/data/dhcpStatic.txt', 'r' )
   try:
      dhcpStatic = f.readline().rstrip ( ' \n\r' )
   except:
      pass       
   f.close ()
   # clear out the file
   f = open ( '/usr/lib/data/dhcpStatic.txt', 'w' )
   f.close()
      

if rebootRequired:
   print 'My ipAddress will be: ' + dhcpStatic
   if dhcpStatic.upper() == 'DHCP':
      print 'Changing files to dhcp'
      utilities.toDHCP ()    
   else:
      print 'Changing files to static'
      utilities.toStatic(dhcpStatic)

   # let boot.py know to reboot the system      
   f = open ( '/usr/lib/data/reboot.txt', 'w')
   f.write ( '1')
   f.close()
else:
   print 'No change to ip address'
   # let boot.py know not to reboot the system
   f = open ( '/usr/lib/data/reboot.txt', 'w')
   f.close()
   
   
