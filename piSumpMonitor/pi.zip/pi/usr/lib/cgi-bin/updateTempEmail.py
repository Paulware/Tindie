#! /usr/bin/env python

import cgi
import cgitb

NUMBEROFDATAVALUES = 6

def updateValue ( lineNumber, tag, index ):
   value = form.getvalue(tag)
   print 'modify line: ' + str(lineNumber) + 'change ' + tag + ' to: ' + value + '<br>'
   count = 0
   
   f = open ( "/usr/lib/data/postTempEmail.txt", "w")
   for line in lines:
      
      if count == lineNumber:
         l = line.rstrip ( ' \n\r' )
         info = l.split ( ':' )
         line = ''
         for i in range (NUMBEROFDATAVALUES):
            if line != '': 
               line = line + ':'
            if i == index:
               line = line + value
            else:
               line = line + info[i]
         print 'This line will be modified to: <br>' 
         print line + '<br>'
         line = line + '\n' 
         
      f.write ( line )
      count = count + 1
   f.close()
   

cgitb.enable() 

print "Content-type: text/html\n\n"
print "<html><body>"
print "<h1>Modify a line</h1>"

form = cgi.FieldStorage()
try:
   if "line" not in form:
      print "please fill in the line number"
      lineNumber = -1
   else:   
      lineNumber = int (form.getvalue("line"))
   
   f = open ("/usr/lib/data/postTempEmail.txt","r")
   lines = f.readlines()
   f.close()
 
   if "destination" in form: 
      updateValue ( lineNumber, 'destination', 0)
      
   elif "aboveBelow" in form:
      updateValue ( lineNumber, 'aboveBelow', 1)
      
   elif "add" in form:    
      print 'add line:<br>'
      f = open ( "/usr/lib/data/postTempEmail.txt", "a")
      f.write ( 'email:above:100:temp1:email:0\n' )
      f.close()
      
   elif "sms" in form:
      updateValue ( lineNumber, "sms", 4 ) 
      
   elif "delete" in form:    
      print 'delete line: ' + str(lineNumber) + '<br>'
      count = 0
   
      f = open ( "/usr/lib/data/postTempEmail.txt", "w")
      for line in lines:
         if count == lineNumber:
            print 'This line will be deleted: <br>' 
            print line + '<br>'
         else:   
           f.write ( line )
         count = count + 1
      f.close()
      
   elif "temperature" in form:
      updateValue ( lineNumber, 'temperature', 2)      
      
   elif "sensor" in form:
      updateValue ( lineNumber, 'sensor', 3)
      
   else:
      print 'Please provide a changed value<br>'
      
   
   if True: # redirect back to editEmailTemps.py
      print 'redirecting back to editEmailTemps.py' + '<br>'
      print '<Script language=\"javascript\">'
      print '   document.location = \"/cgi-bin/editEmailTemps.py\";'
      print '</Script>'
      
except:
   print 'Error somewhere could not getvalue<BR>'  

print '</body></html>'   
   
