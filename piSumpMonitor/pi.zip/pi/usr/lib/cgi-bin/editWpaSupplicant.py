#! /usr/bin/env python  
import Utilities
utilities = Utilities.Utilities() 
print utilities.htmlHeader('updateWpaSupplicantData.py' ) 

print "<hr>"
print "Modify the type or name below to configure the raspberry pi slave node"
print "<hr>"

f = open ("/usr/lib/data/wpaSupplicant.txt","r")
lines = f.readlines() # line[0] is column names, line[1] is values
f.close()

print '<table border=2px>'
info = lines[0].rstrip(' \n\r').split ( ':' )
print '<tr><td>' + info[0] + '</td><td>' + info[1] + '</td></tr>'      

info = lines[1].rstrip (' \n\r').split ( ':' )
print '<tr><td>' 
print utilities.showInput ( 'ssid', info[0], 1) 
print '</td><td>'
print utilities.showInput ( 'psk', info[1], 1)
print '</td></tr></table>'

print '<a href=\"/index.html\">home</a>'
print "</body></html>"