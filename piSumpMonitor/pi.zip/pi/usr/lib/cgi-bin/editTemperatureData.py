#! /usr/bin/env python  
import Utilities   
utilities = Utilities.Utilities() 
print utilities.htmlTopper()

print "<script type=\"text/javascript\">"
print "  function Execute() {"
print "    sensor = document.all.sensor.value;"
print "    action = document.all.action.value;"
print "    document.location = \"/cgi-bin/modifyTemperatureData.py?sensor=\" + sensor + \"&action=\" + action;\n"
print "  }"
print "</Script>"

print "<hr>"
print "Select the action you wish to perform on the data below:"
print "<hr>"

print "<Select name=\"sensor\"><option value=\"temp1\" selected>temp1</option>"
print "<option value=\"temp2\">temp2</option>"
print "<option value=\"temp3\">temp3</option>"
print "<option value=\"temp4\">temp4</option>"
print "</select>"

print "<Select name=\"action\">"
print "<option value=\"purge\" selected>Delete all Data</option>"
print "<option value=\"purge30\">Delete data older than 30 days</option>"
print "<option value=\"half\">Delete every other data point</option>"
print "<option value=\"backup\">Backup data and start over</option>"
print "</select><p>"

print "<input type=button value=\"Execute\" onclick=\"javascript:Execute();\"><p>"

'''
f = open ("/usr/lib/data/wpaSupplicant.txt","r")
lines = f.readlines() # line[0] is column names, line[1] is values
f.close()

print '<table border=2px>'
info = lines[0].rstrip(' \n\r').split ( ':' )
print '<tr><td>' + info[0] + '</td><td>' + info[1] + '</td></tr>'      

info = lines[1].rstrip (' \n\r').split ( ':' )
print '<tr><td>' 
print utilities.showInput ( 'ssid', info[0], 1) 
print '</td><td>'
print utilities.showInput ( 'psk', info[1], 1)
print '</td></tr></table>'
'''
print '<a href=\"/index.html\">home</a>'
print "</body></html>"