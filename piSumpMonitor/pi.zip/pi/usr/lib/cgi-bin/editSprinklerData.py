#! /usr/bin/env python 
import Utilities
utilities = Utilities.Utilities()  

print utilities.htmlHeader('updateSprinklerData.py')

print "<hr>"
print 'Each minute the node will check the current time and look in this table for a matching start time or end time.<br>'
print '&nbsp;&nbsp;&nbsp;If it finds a match, it will turn the relay on or off<br>'
print "Change fields below to configure the sprinkler node"
print "<hr>"

f = open ("/usr/lib/data/sprinklerData.txt","r")
sprinklers = f.readlines() # line[0] is column names, line[1] is values
f.close()

'''
for sprinkler in sprinklers:
   print sprinkler + '<br>'
print '<p>'
'''
first = True
daysOfTheWeek = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday']

print '<table border=2px>'

lineNumber = 1 # skip header
for sprinkler in sprinklers:
   if first:
      info = sprinkler.split ( ':' )
      print '<tr><td>' + info[0] + '</td><td>' + info[1] + '</td><td>' + info[2] + '</td><td>' + info[3] + '</td><td>' + info[4] + '</td><td>' + info[5] + '</td><td>' + info[6] + '</td><td>' + info[7] + '</td><td>' + info[8] + '</td><td>' + info[9] + '</td><td>' + info[10] + '</td><td>' + info[11] + '</td></tr>'      
      # print sprinkler + '<br>' # show header
   else:
      info = sprinkler.rstrip (' \n\r').split ( ':' )
      print '<tr><td>' 
      print utilities.showInput ( 'sprinklerName', info[0], lineNumber) 
      print '</td><td>'
      print utilities.htmlHours ( 'startHour', info[1], lineNumber)
      print '</td><td>'
      print utilities.htmlMinutes ( 'startMinute', info[2], lineNumber)
      print '</td><td>'
      print utilities.htmlHours ( 'endHour', info[3], lineNumber)
      print '</td><td>'
      print utilities.htmlMinutes ( 'endMinute', info[4], lineNumber)
      count = 5
      #print daysOfTheWeek
      for d in daysOfTheWeek:
         print '</td><td>'
         print utilities.onOff ( d, info[count], lineNumber )
         count = count + 1
      print '</td></tr>'
      lineNumber = lineNumber + 1
   first = False
print '</table>'

print "</body></html>"
