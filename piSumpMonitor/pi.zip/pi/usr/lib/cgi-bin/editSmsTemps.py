#! /usr/bin/env python

def select (index, name, list):  
   rule = temps[index].rstrip ( ' \n\r')
   info = rule.split(':')
   #print 'info for : ' + name 
   #print info
   selectedValue = ''
   if name == 'above':
     selectedValue = info[1]

   msg = "<Select name=\"" + name + str(index) + "\">"
   for item in list:
      if selectedValue == item:
         msg = msg + "<option value=\"" + item + "\" selected=\"selected\">" + item + "</option>"
      else:
         msg = msg + "<option value=\"" + item + "\">" + item + "</option>"
      #print '<pre>' + msg + '</pre>'
   msg = msg + "</Select>"
   return msg


print "Content-type: text/html\n\n"
print "<html><body>"

print "<hr>"
print "This configuration allows you to change email temperature settings"
print "<hr>"
print "<form action=\"/cgi-bin/postTempEmail.py\" Method=\"Post\">"

f = open ("/usr/lib/data/postTempEmail.txt","r")
temps = f.readlines()
f.close()

count = 0
for t in temps:
   task = t.rstrip( ' \n\r' )
   info = task.split (':')

   if info.__len__() == 3:
      toAdd = info[0]
      temp = info[2]
      print "Send an email message to <input type=\"text\" size=\"25\" name=\"toAdd" + str(count) + "\" value = \"" + toAdd + "\"><br>"

      print ' when temp1 sensor is ' + select (count, 'above', ['above','below'] )  
      print " <input type=\"text\" size=\"5\" name=\"temp" + str(count) + "\" value = \"" + temp + "\"> Degrees Fahrenheit<br>"

   count = count + 1

print "<input type=\"submit\" value=\"submit\">"
print "</form>"
print "</body></html>"
