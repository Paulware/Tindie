#! /usr/bin/env python
import cgi
import cgitb
cgitb.enable()

print "Content-type: text/html\n\n"
print "<h2>Posting to postTempData.txt</h1>"
form = cgi.FieldStorage()

f = open ("/usr/lib/data/everyMin.txt","r")
tasks = f.readlines()
f.close()

count = 0
f = open ("/usr/lib/data/everyMin.txt","w")
for t in tasks:
   task = t.rstrip( ' \n\r' )
   info = task.split (':')
   try:
      value = form["task" + str(count)].value
   except:
      value = 'off'
   count = count + 1
   if value == 'off':
      f.write ('unchecked:' + info[1] + ':' + info[2] + '\n' )
   else:
      f.write ('checked:' + info[1] + ':' + info[2] + '\n' )
   print 'task' + str(count) + '.value:' + value + '<br>'
f.close()
print "Data successfully written to /usr/lib/data/everyMin.txt<br>"
print "<a href=\"/index.html\">home</a>"
print "<script>\n"
print "  // window.location.href = \"/index.html\";\n"
print "</script>\n"
