#! /usr/bin/env python
import os
from time import localtime, strftime 
import cgi
import cgitb
import datetime
import time

class Utilities ():
   def __init__ (self):
      pass
      
   def filesDifferent ( self, filename1, filename2 ):
      diff = True
      try:
         f = open ( filename1, 'r' )
         data1 = f.read()
         f.close ()
      except:
         data1 = ''      

      try:         
         f = open (filename2, 'r' )
         data2 = f.read()
         f.close () 
      except:
         data2 = '' 
         
      if data1 == data2:
         diff = False
         
      return diff
          
      
   def modificationTime ( self, filename ):
     try:
        (mode, ino, dev, nlink, uid, gid, size, atime, mtime, ctime) = os.stat(filename)
        modTime = time.ctime(atime)
     except:
        modTime = "00:00"
     print modTime   
     return modTime 

   def fileSize ( self, filename ):
      try:
         fSize = os.path.getsize(filename)
      except:
         fSize = 0      
      return fSize
      
   def fileExists ( self, filename ):
      exists = True
      try:
         f = open ( filename, 'r')
         f.close ()
      except:
         exists = False      
      return exists
      
   def timeStamp (self):
      return self.dayOfWeek() + ' ' + self.getLocalTime()
      
   def dayOfWeek (self):
      days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
      weekDay = datetime.datetime.today().weekday()
      return days [weekDay]
   
   def getHourMinute (self):
      return strftime ( '%H:%M', localtime() )   

   def runProcess (self,task):
      print task
      try:
         pipe = os.popen(task)
         a = ' '
         while a != '':
            a = pipe.readline()
            print a
         print 'Done with ' + task   
      except Exception as inst:
         print ' could not ' + task + ' because: ' + str (inst)      
      
   def getLocalTime(self):
      currTime = strftime ( "%Y-%m-%d %H:%M:%S", localtime())
      return currTime      
      
   def readTags (self,filename):
      f = open (filename, 'r')
      # The first line has the tags or column names
      line = f.readline().rstrip ( ' \n\r' )
      f.close()
      tags = line.split ( ':' )
      return tags
   
   def updateValue (self, filename, lineNumber, index, value, lines):
      print 'modify line: ' + str(lineNumber) + 'change element:' + str(index) + ' to: ' + value + '<br>'
      count = 0   
      f = open ( filename, "w")
      for line in lines:
         if count == lineNumber:
            l = line.rstrip ( ' \n\r' )
            info = l.split ( ':' )
            print 'This line will be modified: ' + line + ' new value: ' + value + 'index: ' + str(index) + '<br>'
            line = ''
            for i in range (info.__len__()):
               if line != '': 
                  line = line + ':'
               if i == index:
                  line = line + value
               else:
                  line = line + info[i]
            print 'This line will be modified to: <br>' 
            print line + '<br>'
            line = line + '\n' 
         
         f.write ( line )
         count = count + 1
      f.close()
      
   def updateFormValues (self, filename ):
      
      print "Content-type: text/html\n\n"
      print "<html><body>"
      print "<h1>Modify a line</h1>"

      
      cgitb.enable() 
      form = cgi.FieldStorage()
      tags = self.readTags ( filename )
      print 'Got tags: '
      print tags
      print '<br>'
      try:
         if True:
            print 'Open: ' + filename + '<br>'
            # self.showFile ( filename )
      
            f = open (filename,"r")
            lines = f.readlines()
            f.close()
      
            print 'Number of lines: ' + str ( lines.__len__() ) + '<br>'
      
            if lines.__len__() == 0:
               print filename + ' is empty'  
            else: # check lineNumber
               lineNumber = int ( form.getvalue ( 'line' ) )
               if "column" in form: 
                  columnName = form.getvalue("column")
                  count = 0
                  index = -1
                  for tag in tags:
                     if tag == columnName:
                        index = count                  
                        print '<br>Matched ' + tag + ' on index: ' + str (index) + '<br>'
                        break
                     count = count + 1
                  if index == -1: 
                     print 'Could not find : ' + columnName + ' in line 0 of ' + filename 
                  elif "value" not in form:
                     print 'No new value specified for ' + columnName
                  else:            
                     self.updateValue ( filename, lineNumber, index, form.getvalue('value'), lines)      
               else:
                  print 'Please provide a changed value<br>'      
      except:
         print 'Error somewhere could not getvalue<BR>'  
         
   def javascriptUpdateValue ( self, updateFilename ):
      msg = '<Script language=\"javascript\">\n'
      msg = msg + '   function updateValue ( headerName, value, lineNumber )\n'
      msg = msg + '   {\n'     
      msg = msg + '       document.location = \"/cgi-bin/' + updateFilename + '?column=\" + headerName + \"&value=\" + value + \"&line=\" + lineNumber;\n'
      msg = msg + '   }\n' 
      msg = msg + '</Script>'   
      return msg
   
   def htmlTopper(self):
      msg = "Content-type: text/html\n\n"
      msg = msg + "<html><body>\n"
      return msg
      
   def htmlHeader ( self, updateFilename ):
      return self.htmlTopper() + self.javascriptUpdateValue ( updateFilename )
      
   def showInput (self, name, value, lineNumber):
      return "<input type=\"text\" size=\"25\" onChange=\"javascript:updateValue(\'" + name + "',this.value," + str(lineNumber) + " );\" value = \"" + value + "\">"
   
   def onOff (self, name, value, lineNumber):
      msg = '<Select onchange=\"javascript:updateValue(\'' + name + '\',this.value,' + str(lineNumber) + ');\">"'   
      onOffs = {'on', 'off'}
   
      for onOff in onOffs:      
         if onOff == value:
            msg = msg + '<option value=\"' + onOff + '\" selected=\"selected\">' + onOff + '</option>'
         else:
            msg = msg + '<option value=\"' + onOff + '\">' + onOff + '</option>'
      msg = msg + '</Select>'      
      return msg
   

   def htmlHours (self, headerName, value, lineNumber):
      msg = '<Select onchange=\"javascript:updateValue(\'' + headerName + '\',this.value,' + str(lineNumber) + ');\">"'   
   
      for hour in range (24): 
         hr = str (hour)
         if hour < 10:
            hr = '0' + hr
         if hour == int(value):
            msg = msg + '<option value=\"' + hr + '\" selected=\"selected\">' + hr + '</option>'
         else:
            msg = msg + '<option value=\"' + hr + '\">' + hr + '</option>'
      msg = msg + '</Select>'      
      return msg
   
   def htmlMinutes (self, headerName, value, lineNumber):
      msg = '<Select onchange=\"javascript:updateValue(\'' + headerName + '\',this.value,' + str(lineNumber) + ');\">"'   
      
      for minute in range (60):
         min = str(minute)
         if minute < 10:
            min = '0' + min
         
         if minute == int(value):
            msg = msg + '<option value=\"' + min + '\" selected=\"selected\">' + min + '</option>'
         else:
            msg = msg + '<option value=\"' + min + '\">' + min + '</option>'
      msg = msg + '</Select>'      
      return msg

   # date +\%Y\%m\%d\%H\%M\%S
   # dateStamp is in above format
   # 20140107225901  
   def elapsedDays (self, dateStamp ):
      year = int ( dateStamp [0:4] )
      month = int ( dateStamp [4:6] )
      day = int ( dateStamp [6:8] )
      hour = int ( dateStamp [8:10] )
      minute = int ( dateStamp [10:12] )
      second = int ( dateStamp [12:14] )

      a = datetime.datetime(year, month, day, hour, minute, second )      
      elapsed = (datetime.datetime.now()-a).total_seconds() / (3600 * 24 )
      return elapsed 
      
   def backupTemperatureData ( self, filename ):
      f = open (filename, 'r')
      lines = f.readlines ()
      f.close()
      
      f = open (filename + '.bak' , 'a' )
      for line in lines:
         f.write ( line )
      f.close()
      
      # delete the current dat 
      f = open ( filename, 'w' )
      f.close()
      
   def purgeData (self,filename,maxDays):
      f = open (filename, 'r')
      lines = f.readlines ()
      f.close()
      
      f = open (filename, 'w' )
      count = 0 
      for line in lines:
         count = count + 1
         info = line.rstrip(' \n\r').split ( ',' )
         if info.__len__() == 3:
            if self.elapsedDays ( info[0] ) <= maxDays:
               f.write ( line )                         
      f.close()
   
      
   def halfTheData ( self,filename ):   
      f = open (filename, 'r')
      lines = f.readlines ()
      f.close()
      
      startCount = lines.__len__()
      
      skipLine = False
      f = open (filename, 'w' )
      endCount = 0
      for line in lines:
         info = line.rstrip(' \n\r').split ( ',' )
         if info.__len__() == 3:
            # Check if data is real
            #print 'info[1]=' + info[1] + str(info[1].__len__()) + ',info[2]=' + info[2] + str(info[2].__len__()) + '<BR>'
            if (info[1] == '') and (info[2] == ''):
               skipLine = False # use the next line but not this one
               #print 'Skipping<BR>'
            elif skipLine:
               skipLine = False
               #print 'skipping<br>'
            else:
               endCount = endCount + 1
               f.write ( line )
               skipLine = True
         else:
            skipLine = False
            
      print 'Line count changed from ' + str(startCount) + ' to: ' + str (endCount)      
      f.close ()         
      
   def lastTemp (self,filename):
      # Get last temperature readings from log files
      f = open (filename, 'r')
      lastTemp = 0.0
      lines = f.readlines ()
      f.close()
      for line in lines:
         info = line.split ( ',' )
         if info.__len__() == 3:
            try:
               temp = float(info[2])
               lastTemp = temp
            except:
               pass
      
      # Check if we need to shorten the file.
      if lines.__len__() > 4000:
         self.halfTheData (filename)
         
      return lastTemp

        
   def toStatic (self, ipAddress):      
      # Write to /usr/lib/data/cmdline.txt this will cause boot.py to reboot
      # This will be copied over to /boot/cmdline.txt by /etc/rc.local
      f = open ( '/usr/lib/data/cmdline.txt', 'w') 
      f.write ( 'dwc_otg.lpm_enable=0 console=ttyAMA0,115200 kgdboc=ttyAMA0,115200 console=tty1 root=/dev/mmcblk0p2 rootfstype=ext4 elevator=deadline rootwait\n' )
      f.write ( 'ip=' + ipAddress )
      f.close()

      # This will be copied over to /etc/network/interfaces by /etc/rc.local
      f = open ( '/etc/network/interfaces', 'w' )            
      f.write ( 'auto lo\n' )
      f.write ( 'iface lo inet loopback\n')
      f.write ( '\n')
      
      f.write ( 'auto eth0\n' )      
      f.write ( 'iface eth0 inet static\n' )
      f.write ( 'address ' + ipAddress + '\n' )
      f.write ( 'netmask 255.255.255.0\n' )
      f.write ( '\n' )
      
      f.write ( 'allow-hotplug wlan0\n' )
      f.write ( 'iface wlan0 inet manual\n' )
      f.close ()     
      # print 'Converted to static!, please reboot'
      
   def toDHCP (self):   

      # Write to /usr/lib/data/cmdline.txt this will cause boot.py to reboot
      # This will be copied over to /boot/cmdline.txt by /etc/rc.local
      f = open ( '/usr/lib/data/cmdline.txt', 'w') 
      f.write ( 'dwc_otg.lpm_enable=0 console=ttyAMA0,115200 kgdboc=ttyAMA0,115200 console=tty1 root=/dev/mmcblk0p2 rootfstype=ext4 elevator=deadline rootwait\n' )
      f.close()       
      
      f = open ( '/etc/network/interfaces', 'w' )            
      f.write ( 'auto lo\n' )
      f.write ( 'auto eth0\n\n' )
      f.write ( 'iface lo inet loopback\n' )
      f.write ( 'iface eth0 inet dhcp\n\n' )
      f.write ( 'allow-hotplug wlan0\n' )
      f.write ( 'iface wlan0 inet manual\n' )
      f.write ( 'wpa-roam /etc/wpa_supplicant/wpa_supplicant.conf\n' )
      f.write ( 'iface default inet dhcp\n') 
      #f.write ( '\twpa-ssid \"RichardsWiFi\"\n' )
      #f.write ( '\twpa-psk \"Star123!\"\n\n' )
      f.close ()      
      
   def showFile (self,filename):
      f = open ( filename, 'r')
      lines = f.readlines()
      f.close()
      print '<br><br><h1>' + filename + '</h1>'
 
      for line in lines:
         print line.rstrip (' \n\r' ) + '<br>'
      print '<p>'