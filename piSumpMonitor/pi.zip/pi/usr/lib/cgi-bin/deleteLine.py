#! /usr/bin/env python

import cgi
import cgitb
cgitb.enable() 

print "Content-type: text/html\n\n"
print "<html><body>"
print "<h1>Delete a line yes?</h1>"

form = cgi.FieldStorage()
try:
   lineNumber = int (form.getvalue("line"))
   print 'delete line: ' + str(lineNumber) + '<br>'
   f = open ("/usr/lib/data/postTempEmail.txt","r")
   lines = f.readlines()
   f.close()
   count = 0
   f = open ( "/usr/lib/data/postTempEmail.txt", "w")
   for line in lines:
      if count == lineNumber:
         print 'This line is deleted: <br>' 
         print line + '<br>'
      else:
         f.write ( line )
      count = count + 1
   f.close()
   print 'redirecting back to editEmailTemps.py' + '<br>'
   print '<Script language=\"javascript\">'
   print '   document.location = \"/cgi-bin/editEmailTemps.py\";'
   print '</Script>'
      
except:
   print 'Could not getvalue (line)<BR>'  
   
 

print '</body></html>'   
   
