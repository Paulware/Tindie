#! /usr/bin/env python
def select (index,name, list):  
   rule = rules[index].rstrip ( ' \n\r')
   info = rule.split(':')
   #print 'info for : ' + name 
   #print info
   selectedValue = ''
   if name == 'energized':
     selectedValue = info[1]
   elif name == 'relay':
     selectedValue = info[0]
   elif name == 'above':
     selectedValue = info[2]
   elif name == 'sensor':
     selectedValue = info[4]

   msg = "<Select name=\"" + name + str(index) + "\">"
   for item in list:
      if selectedValue == item:
         msg = msg + "<option value=\"" + item + "\" selected=\"selected\">" + item + "</option>"
      else:
         msg = msg + "<option value=\"" + item + "\">" + item + "</option>"
      #print '<pre>' + msg + '</pre>'
   msg = msg + "</Select>"
   return msg

print "Content-type: text/html\n\n"
print "<html><body>"

f = open ("/usr/lib/data/postTempData.txt","r")
rules = f.readlines()
f.close()

print "<hr>"
print "<h1>Temp Relay Rules</h1>"
print "These rules will control up to 4 relays based on the temperature of 3 sensors"
print "<hr> Note:<br> When a relay is energized the normally open output is connected to the common input<br>"
print " When a relay is de-energized the normally closed output is connected to the common input"
print "<hr>"
print "<form action=\"/cgi-bin/postTempData.py\" Method=\"Post\">"

for i in range (8):
   print "Relay : " + select (i,'relay', ['None','1','2','3','4']) + ' shall be '
   print select (i,'energized', ['energized','de-energized']) 
   print ' when sensor ' + select (i, 'sensor', ['1','2','3'] )  
   print ' ' + select (i, 'above', ['above','below'] )  
   rule = rules[i]
   info = rule.split(':')
   print " <input type=\"text\" size=\"5\" name=\"temp" + str(i) + "\" value = \"" + info[3] + "\"> Degrees Fahrenheit<br>"

print "<input type=\"submit\" value=\"submit\">"
print "</form>"
print "</body></html>"