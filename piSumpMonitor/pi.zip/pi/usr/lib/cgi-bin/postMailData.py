#! /usr/bin/env python
import cgi
import cgitb

def showFile ( filename ):
   print '<h1>' + filename + '</h1>'
   f = open (filename, 'r' )
   lines = f.readlines()
   f.close

   for line in lines:
      print line + '<br>'

cgitb.enable()

print "Content-type: text/html\n\n"
print "<h2>Posting to postMailData.txt</h1>"
form = cgi.FieldStorage()
if "username" not in form:
   print "<h1>The username input box was empty.</h1>"
elif "password" not in form:
   print "<h1>The password input box was empty.</h1>"
else:
   username=form["username"].value
   password=form["password"].value
   toAddress=form["toAddress"].value
   phoneProvider=form["phoneProvider"].value
   print "Text from text input box:<hr>"
   print cgi.escape(username ) + '<br>'
   print cgi.escape(password ) + '<br>'
   print cgi.escape(toAddress ) + '<br>'
   print cgi.escape(phoneProvider) + '<br>'
   f = open ("/usr/lib/data/postMailData.txt","w")
   f.write ( username + '\n' )
   f.write ( password + '\n' )
   f.write ( toAddress + '\n' )
   f.write ( phoneProvider + '\n' )
   f.write ( 'last.Ip.addr.ess\n') # Written to by checkIp.py 
   f.write ( 'currentTime' ) # Written to by checkIp.py
   f.close()
  
   f = open ( "/etc/ssmtp/ssmtp.conf", "w")
   f.write ( 'root=' + username + '\n' )
   f.write ( 'mailhub=smtp.gmail.com:587\n' )
   f.write ( 'hostname=raspberrypi\n')
   f.write ( 'AuthUser=' + username + '@gmail.com\n')
   f.write ( 'AuthPass=' + password + '\n')
   f.write ( 'UseSTARTTLS=YES\n' )
   f.close()

   showFile ( '/etc/ssmtp/ssmtp.conf' )
   showFile ( '/usr/lib/data/postMailData.txt' )

   print "<p><h1>Data successfully written</h1><br>"
   print "<a href=\"/index.html\">home</a>"
   print "<script>\n"
   print "  window.history.back();"
   print "</script>\n"
