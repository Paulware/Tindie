#include <stdio.h>
void main (int argc, char *argv[])
{
  printf ( "Content-type: text/html\n\n" );
  printf ( "<html><head><title>Test</title></head><body>" );
  printf ( "Hello from c</body></html>" );
}
