#include <stdio.h>
#include <stdlib.h>
int main(void)
{
  char *data;
  long m,n;
  printf ("Content-Type:text/html \n\n");
  printf ("<TITLE>Multiplication</TITLE><H3>Multiplication</H3>" );
  data = getenv ("QUERY_STRING");
  if (data == NULL)
    printf ("<P>Error! Error in passing data from form to script.");
  else if (sscanf(data,"m=%ld&n=%ld",&m,&n) != 2)
    printf ("<P>Error! Invalid data.  Data must be numeric." );
  else
    printf ("<P>The product of %ld and %ld is %ld.",m,n,m*n);
}

