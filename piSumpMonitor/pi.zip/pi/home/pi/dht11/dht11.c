#include <wiringPi.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#define MAX_TIME 85
#define ATTEMPTS 5
#define DEBUGIT 0
int dht11_val[5]={0,0,0,0,0};
 
int dht11_read_val(int pin)
{
  if (DEBUGIT)
    printf ( "Reading pin %d\n", pin );
  uint8_t lststate=HIGH;
  uint8_t counter=0;
  uint8_t j=0,i;
  int f=0;
  uint8_t f1,f2;
  for(i=0;i<5;i++)
     dht11_val[i]=0;
  pinMode(pin,OUTPUT);
  digitalWrite(pin,LOW);
  delay(18);
  digitalWrite(pin,HIGH);
  delayMicroseconds(40);
  pinMode(pin,INPUT);
  for(i=0;i<MAX_TIME;i++)
  {
    counter=0;
    while(digitalRead(pin)==lststate){
      counter++;
      delayMicroseconds(1);
      if(counter==255)
        break;
    }
    lststate=digitalRead(pin);
    if(counter==255)
       break;
    // top 3 transistions are ignored
    if((i>=4)&&(i%2==0)){
      dht11_val[j/8]<<=1;
      if(counter>16)
        dht11_val[j/8]|=1;
      j++;
    }
  }
  // verify checksum and print the verified data
  if((j>=40)&&(dht11_val[4]==((dht11_val[0]+dht11_val[1]+dht11_val[2]+dht11_val[3])& 0xFF)))
  {
    
    f = (dht11_val[2] * 100) +  dht11_val[3];
    f = f * 9;
    f = f / 5;
    f += 3200;
    f1 = f / 100;
    f2 = f % 100;
    
    printf("%d.%d,%d.%d\n",dht11_val[0],dht11_val[1],f1,f2);
    return 1;
  }
  else
  {
    printf (",\n");
 //   if (DEBUGIT)
 //     printf ( "Missing dht11\n" );
 //   printf ("0.1,0.2\n");
    return 1;
  }
}
 
int main(int argc, char *argv[])
{
  int attempts=ATTEMPTS;
  uint8_t i;
  int pin = 0;
  if (!strcmp (argv[1], "gpio4"))
    pin = 7;
  else if (!strcmp (argv[1], "gpio22"))
    pin = 3;
  else if (!strcmp (argv[1], "gpio23"))
    pin = 4;
  else if (!strcmp (argv[1], "gpio24"))
    pin = 5;

  if (DEBUGIT)
  {
    if (pin)
      printf ( "Got pin %d\n",pin);
    else
      printf ( "Could not figure out which pin to use\n");
  }

  //for (i=0; i<argc; i++)
  //   printf ( "argv[%d]: %s\n",i,argv[i] );
  if(wiringPiSetup()==-1)
    exit(1);

  /* 
  for (i=0; i<26; i++)
  {
    int s = dht11_read_val (i);
    if (s) 
   {
     printf ( "pin %d worked!",i);
   }
  }
  */

   
  while(attempts)
  {
    int success = dht11_read_val(pin);
    if (success) {
      break;
    }
    attempts--;
    delay(500);
  }
  if (!attempts)
    printf ( "0.0,0.0\n");
  return 0;
  
}
