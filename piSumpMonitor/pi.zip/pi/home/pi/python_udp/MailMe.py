import os 
import smtplib 
import socket 
from time import gmtime, strftime 
import re 
class MailMe ():
   def getCurrTime(self):
      currTime = strftime ( "%Y-%m-%d %H:%M:%S", gmtime())
      return currTime

   def getLocalAddress (self):
      ipAddress = ''
      try:
         s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
         s.connect ( ('gmail.com', 80))
         ipAddress = s.getsockname()[0]
         s.close()
      except:
         pass
      return ipAddress

   def getIpAddress(self):
      ipAddress = ''
      try: 
         os.popen ( 'cd /home/pi' )
         os.popen ( 'rm -f index.html')
         os.popen ( 'wget -4 http://checkip.dyndns.org')
         f = open ( 'index.html','r' )
         line = f.read()
         f.close()
         ipAddress = re.findall (r'\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b',line)[0]
      except:
         pass      
      return ipAddress

   def wakeupEmail (self):
      smtpUser = 'paulrussellrichards@gmail.com' # 'yourusername@gmail.com'
      smtpPass = 'hello?6cf' # 'yourpasword'
      toAdd = 'joec@portfourchon.com' # youremailaddress'
      subject = 'waking up'
      header = 'To: ' + toAdd + '\nFrom: ' + smtpUser + '\nSubject: Waking up'
      body = self.getCurrTime() + '\nHello from pi at: ' + self.getIpAddress() + '\nMy local address is: ' + self.getLocalAddress()
      print header + '\n' + body
      try:
         s = smtplib.SMTP ('smtp.gmail.com', 587)
         s.ehlo()
         s.starttls()
         s.ehlo()
         s.login (smtpUser, smtpPass)
         s.sendmail ( smtpUser, toAdd, header + '\n' + body)
         s.quit()
      except:
         pass      
      
m = MailMe()
m.wakeupEmail ()  
