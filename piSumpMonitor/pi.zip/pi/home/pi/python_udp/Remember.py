'''
   This is a self modifying class to persist a value, rather than using a text file
   Usage:
      import Remember
      
      r = Remember.Remember()
      r.names[0] = 'new Value'
      r.Save()
'''
class Remember:
             
    def __init__ (self):
        self.names = ['blue','timer2','light brown','sprinkler','right middle','white','sidewalk','pink']
        self.startAt = [804,300,500,515,545,1100,615,1500]
        self.endAt = [200,400,600,530,600,1200,630,1600]
        self.daysOfWeek = [0,0,0,127,127,0,127,0]
        
        self.ipAddress = 'deviceId1'
        self.enabledMtg = False

    def copyFile (self,file1,file2):
        inFile = open ( file1,'r')
        outFile = open ( file2, 'w')
        while (True):
            line = inFile.readline()
            if line:
                outFile.write ( line )
            else:
                break
        outFile.close()
        inFile.close()  

    def initializingGlobal ( self, line, name ):
        initializing = False
        if (line.find (name) > -1) and (line.find ( 'line.find') == -1) and (line.find ('outFile') == -1) and (line.find ('initializingGlobal') == -1):
           initializing = True
        return initializing
        
    def save (self):
        inFile = open ( 'Remember.py', 'r' )
        outFile = open ('temp.py','w')
        while (True):
            line = inFile.readline()
            if line:
                # string
                if self.initializingGlobal ( line,'deviceId ='):
                    outFile.write ( '        self.deviceId = \'' + self.deviceId + '\'\n')
                # boolean
                elif self.initializingGlobal ( line,'enabledMtg ='):
                    if self.enabledMtg:
                        outFile.write ( '        self.enabledMtg = True\n' )
                    else: 
                        outFile.write ( '        self.enabledMtg = False\n' )                                            

                # int array                        
                elif self.initializingGlobal ( line,'startAt = ['):
                    outFile.write ( '        self.startAt = [' )
                    for i in range (0, len(self.startAt)):
                        if i > 0:
                            outFile.write ( ',' )
                        outFile.write ( str(self.startAt[i]) )
                    outFile.write ( ']\n' )                
        
                # int array                        
                elif self.initializingGlobal ( line,'endAt = ['):
                    outFile.write ( '        self.endAt = [' )
                    for i in range (0, len(self.endAt)):
                        if i > 0:
                            outFile.write ( ',' )
                        outFile.write ( str(self.endAt[i])  )
                    outFile.write ( ']\n' )                
        
                elif self.initializingGlobal ( line,'names = ['):
                    outFile.write ( '        self.names = [' )
                    for i in range (0, len(self.names)):
                        if i > 0:
                            outFile.write ( ',' )
                        outFile.write ( '\'' + str(self.names[i]) + '\'' )
                    outFile.write ( ']\n' )                
        
                elif self.initializingGlobal ( line,'daysOfWeek = ['):
                    outFile.write ( '        self.daysOfWeek = [' )
                    for i in range (0, len(self.daysOfWeek)):
                        if i > 0:
                            outFile.write ( ',' )
                        outFile.write ( str(self.daysOfWeek[i])  )
                    outFile.write ( ']\n' )                
        
                else:
                    outFile.write ( line )              
            else:
                break
        outFile.close()
        inFile.close()
        self.copyFile ( 'temp.py', 'Remember.py' )

    def deleteString ( self, array, searchString ):
        try: 
            x = array.index (searchString)
            array[x:x+1] = []
        except:    
            print ( 'Could not delete ' + searchString + ' from: ' )
            print ( array )  
        
    def appendString ( self, array, searchString ):
        try: 
            x = array.index (searchString)
            print ( 'Could not append: ' + searchString + ' it already exists in: ' )
            print ( array )      
        except:    
            array.append (searchString)  