#Master.py

'''
   Each gui will have its own communications class will send commands and expect 
   responses.  
   The slave object will not need to be known at the gui level, as all information 
   will be passed that is neccessary to sent to device.
'''


import socket
import time
import Tkinter 
import threading
import ttk
import Remember
import os
import Sprinkler
import sys

#port datetime

COMMAND_PORT = 4000
TYPENUMBER = 1 # sprinkler 2 # Water sensor box
state = 0
DEBUGIT = True
if DEBUGIT:
  RESPONSE_TIME = 0.01
  MAXTRIES = 2
else:
  RESPONSE_TIME = 1.0  
  MAXTRIES = 5
  
MAXNODES = 8 #Maximum number of enc28j60 nodes in the network

class WaterSensor ():
   def __init__ (self,gui,slave,remember):
      self.sensors = []
      self.communicationsClass = slave.commClass
      self.name = slave.name
      self.remember = remember      
      self.gui = gui
      self.top = Tkinter.Toplevel()
 
      frame = Tkinter.Frame (self.top)
      frame.pack (side=Tkinter.TOP)
      frame.title = 'Water Sensor box'      
      
      deviceIdFrame = Tkinter.Frame (frame)
      deviceIdFrame.pack (side=Tkinter.TOP)
      label = Tkinter.Label (deviceIdFrame, text='Device Id:')
      label.pack (side=Tkinter.LEFT)   
      self.myId = Tkinter.StringVar()         
      entry = Tkinter.Entry ( deviceIdFrame, textvariable=self.myId)
      entry.bind('<KeyRelease>', self.deviceIdPress)
      entry.pack(side=Tkinter.LEFT)         
      self.reversePin = Tkinter.StringVar()  
      label = Tkinter.Label (deviceIdFrame, text='IP Address')
      label.pack (side=Tkinter.LEFT)
      self.myIpAddress = Tkinter.StringVar()
      entry = Tkinter.Entry ( deviceIdFrame, textvariable =self.myIpAddress)
      entry.bind ( '<KeyRelease>', self.ipAddressPress)
      entry.pack(side=Tkinter.LEFT)   
      label = Tkinter.Label (deviceIdFrame, text='Response Index')
      label.pack (side=Tkinter.LEFT)
      self.responseIndex = Tkinter.StringVar()
      entry = Tkinter.Entry ( deviceIdFrame, textvariable=self.responseIndex)
      entry.pack(side=Tkinter.LEFT)
      entry.bind('<KeyRelease>', self.responseIndexPress)              
      button = Tkinter.Button (deviceIdFrame, text=u"Save", command=self.saveWaterBox)
      button.pack (side=Tkinter.TOP)                  
      
      label = Tkinter.Label (frame, text='Water Sensor Box:')
      label.pack (side=Tkinter.LEFT)   
      
      frame = Tkinter.Frame (self.top)
      frame.pack (side=Tkinter.TOP)
      
      for i in range(8):
         self.sensors.append (Tkinter.StringVar())
         label = Tkinter.Label (frame, textvariable=self.sensors[i])
         label.pack (side=Tkinter.TOP)
         self.sensors[i].set ( 'Sensor ' + str(i) + ' no water detected')      
         
      button = Tkinter.Button (frame, text=u"Poll Device for Update",command=self.updateSensors)
      button.pack (side=Tkinter.TOP)
      
      self.readWaterBoxInfo ()

   def readWaterBoxInfo(self):
      # get Device Id
      self.SendCommand ('readDeviceId' )      
      self.handleResponse('readDeviceId')
     
      self.SendCommand ('readIpAddress')
      self.handleResponse('readIpAddress')
      
      self.SendCommand ('readResponseIndex')
      self.handleResponse('readResponseIndex')
      
      self.updateSensors()
      
   def handleResponse(self, response):
      # give time for slave to listen
      startTime = time.time()
      seconds = 2      
      while time.time() < startTime + seconds:
         info = self.communicationsClass.checkResponse()  
         if info != None:         
            if info[0] == 'Master': # This is for me
               print 'info: ' + str(info)
               if info[2] == response:
                  if response == 'readDeviceId':
                     self.myId.set(info[3])
                  elif response == 'readIpAddress':
                     ipAddress = ''
                     for bytes in info[3:]:
                        if ipAddress == '':
                           ipAddress = bytes
                        else:
                           ipAddress = ipAddress + '.' + bytes                        
                     self.myIpAddress.set(ipAddress)
                  elif response == 'readResponseIndex':
                     self.responseIndex.set (info[3])                     
                  elif response == 'readSensor':
                     if info[4] == '1': 
                        print 'Sensor ' + str(info[3]) + 'is set!'
                     else:
                        print 'Sensor ' + str(info[3]) + 'is not set'                     
                  break
               else:
                  print 'handleResponse confused by: ' + info[2]            
                     
         
   def SendCommand (self,command):
      message = self.name + ':' + command + chr(0)
      self.communicationsClass.sockSendTo (message)          
      print 'Sent command: ' + message

   def updateSensors (self):  
      for i in range(4):
        self.SendCommand ( 'readSensor ' + str(i))
        self.handleResponse('readSensor')        
                      
   def setStatus ( self, sensor, text ):
      self.sensors[sensor].set (text)

   def renameId ( self, oldName, newName ):
      print 'Search for this name in the list: ' + oldName + ' replace it with this name: ' + newName
      self.gui.slaves.renameSlave (oldName,newName)
      self.gui.showSlaves()
      
   def deviceIdPress (self, event):
      name = self.myId.get()
      if name != '':
         cmd = 'writeDeviceId' + name
         print cmd
         self.SendCommand (cmd)      
         self.renameId ( self.name, name)
         self.name = name
      
   def ipAddressPress (self,event):
      ipAddress = self.myIpAddress.get()
      cmd = 'writeIpAddress' + ipAddress
      self.SendCommand (cmd)
      
   def responseIndexPress (self, event):    
      print 'In responseIndexPress'   
      responseIndex = self.responseIndex.get()
      cmd = 'writeResponseIndex ' + responseIndex
      self.SendCommand (cmd)
      
   def saveWaterBox (self):
      self.remember.save()        
      
