#Master.py

'''
   Each gui will have its own communications class will send commands and expect 
   responses.  
   The slave object will not need to be known at the gui level, as all information 
   will be passed that is neccessary to sent to device.
'''


import socket
import time
import Tkinter 
import threading
import ttk
import Remember
import os
import Sprinkler
import WaterSensor
import sys
import smtplib
from time import gmtime, strftime
import re


#port datetime

COMMAND_PORT = 4000
TYPENUMBER = 1 # 1 sprinkler  # 2 Water sensor box
state = 0
DEBUGIT = False
if DEBUGIT:
  RESPONSE_TIME = 0.01
  MAXTRIES = 2
else:
  RESPONSE_TIME = 1.0  
  MAXTRIES = 5
  
MAXNODES = 4 #Maximum number of enc28j60 nodes in the network

def getIpAddress():
   os.popen ( 'cd /home/pi' )
   os.popen ( 'rm -f index.html')
   os.popen ( 'wget -4 http://checkip.dyndns.org')
   try:
      f = open ( 'index.html','r' )
      line = f.read()
      f.close()
      ipAddress = re.findall (r'\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b',line)[0]
   except:
      ipAddress = ''
   return ipAddress
   
def getCurrTime():
   currTime = strftime ("%Y-%m-%d %H:%M:%S", gmtime())   
   return currTime

class MailMe ():
   def __init__(self):
      self.smtpUser = 'paulrussellrichards@gmail.com'
      self.smtpPassword = 'hello?6cf'
      self.toAddress = 'paulware@hotmail.com'

   def sendMail (self, subject, body):
      header = 'To: ' + self.toAddress + '\nFrom: ' + self.smtpUser + '\nSubject: ' + subject
      print header + '\n' + body
      try:
         s = smtplib.SMTP ('smtp.gmail.com', 587)
         s.ehlo()
         s.starttls()
         s.ehlo()
         s.login (self.smtpUser, self.smtpPassword)
         s.sendmail ( self.smtpUser, self.toAddress, header + '\n' + body)
         s.quit()
      except:
         pass
                    
   def wakeupEmail (self):
      currTime = strftime ("%Y-%m-%d %H:%M:%S", gmtime())
      body = 'Hello from: ' + getIpAddress() + ' ' + getCurrTime()
      self.sendMail ( 'waking up', body )

class Slave ():
   def __init__ ( self, name, sock, commClass ):
      self.sock = sock
      self.name = name
      self.state = 'Unknown'
      self.typeName = 'Unknown Type'
      self.typeNumber = 0
      self.timeout = time.time()
      self.commClass = commClass
      
   def setDeviceType (self,typeNumber):
      self.typeNumber = typeNumber
      if typeNumber == 0:
         self.typeName = 'ENC28J60'
      elif typeNumber == 1:
         self.typeName = 'Sprinkler'      
      elif typeNumber == 2:
         self.typeName = 'Water Sensor'      
      else: 
         self.typeName = 'unknownType' + str(typeNumber)      
         print 'Got an unknown type of : ' + str (typeNumber)
      
   def setState (self, state ):
      self.state = state
      print self.name + ' state set to ' + state
      
   def setType (self,typeName ):
      self.typeName = typeName
      print 'Slave type set to : ' + typeName      
       
   def disconnect (self):
      print 'tell slave to close, and close the socket'
      try: 
         self.sock.send ('DISCONNECT')
         self.sock.shutdown(2)
         self.sock.close()  
         self.sock = ""   
      except:
         print 'Could not close the socket'      
      print 'done closing the socket'
      
# Array of slaves         
class Slaves:
   def __init__ (self):
      self.slaves = []
      
   def setCommClass (self,commClass):
      self.commClass = commClass   
      
   def slaveExists (self, name ):
      found = False
      for slave in self.slaves: 
         if slave.name == name:
            found = True
            break            
      return found

   def addSlave (self,slaveName,sock):  
      if self.slaveExists (slaveName):
         print 'This slave already exists: ' + slaveName
      else:
         slave = Slave (slaveName,sock, self.commClass)
         self.slaves.append ( slave )
         
   def getAvailableSlaves (self):
      available = []
      for slave in self.slaves:
         if slave.state == 'Available':
            available.append (slave)
      print available      
      return available            
         
   def findSlave ( self,name):
      if self.slaveExists (name):
         for slave in self.slaves:
            if slave.name == name: 
               break
         return slave
      return None
      
   def renameSlave (self,oldName,newName ):
      slave = self.findSlave (oldName)
      if slave != None:
         slave.name = newName
         print 'slave ' + oldName + ' got a newName: ' + newName 
      else:
         print 'ERR could not find slave: ' + oldName
   
     
class CommunicationsClass ():
   def __init__ (self, slaves, gui):
      self.gui = gui
      self.nextPort = 4001        
      self.slaves = slaves            
      self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM) #UDP
      self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1) #Broadcast
      self.localAddress = socket.gethostbyname(socket.gethostname()) 
      print 'My ipaddress is: ' + self.localAddress 
      self.sock.bind ( ("",COMMAND_PORT) ) # now listen at the COMMAND_PORT for responses (use different ports?)
      self.sock.setblocking (0)
      
   def sockSendTo (self,message):
      self.sock.sendto(message, ("255.255.255.255", COMMAND_PORT))   
      
   def sendto (self, message, needResponse, maxTries = MAXTRIES ):
      done = False
      first = True
      count = 0
      while not done:      
         try:               
            if count < maxTries:
               if count > 0:
                 print 'Sending this again because did not get a response'               
               count = count + 1
               self.sockSendTo (message + chr(0) )
            else:
               done = True
               print 'Quitting after trying ' + str(maxTries) + ' times to send...NO RESPONSE'
               print 'Check Internet Connection'
            
         except:
            done = True
            print 'The network appears to be unavailable cannot sendto: ' + message
         
         if needResponse:         
            if not done:
               print 'Now sending: ' + message     
               if self.getResponse (RESPONSE_TIME):    
                  done = True            
                  print '\ngot Response sendto ( ' + message + ')\n'
         else: # No Response necessary
            done = True         
            self.getResponse (RESPONSE_TIME) #wait the time for next communication
         first = False      
     
   def sendNameCommand ( self, name, command ):
      message = name + ':' + command + chr(0)
      self.sendto ( message, True )   
             
   def sendCommand ( self,slave,command):
      self.sendNameCommand (slave.name, command )

   def sendHello (self):
      message = "Hello "
      for i in range(MAXNODES):
        self.sendto ( message + str(i), True, 1 )

   def checkResponse (self):
      ok = True
      try: 
        data = self.sock.recv (1024)
      except:
        ok = False
      
      info = None       
      if ok:
         if data:
            info = data.split ( ':' )
      if info != None:      
         print info		
      return info 
      
   def addTestSlave (self):
      slaveName = 'Test1'
      self.slaves.addSlave (slaveName, self.sock)        
      slave = self.slaves.findSlave (slaveName)
      slave.setState ('Available')
      slave.typeNumber = TYPENUMBER       
      self.gui.addSlave (slave) # This should select the slave  
 
   '''
      Handle all responses from the slaves.
   '''   
   def canHandleResponse (self, info):
      canHandle = True
      response = info[0]
      '''
         Format of Hello from Slave:
            Master:MyId:Hello:Status
               
         Format of everything else from slave:
            MyType:MyId:Response   
      '''
      if response == 'Master': # Slave is giving info responses  
         print 'Got slave info ' + str(len(info)) + ' items long' 
         print info
         if len(info) > 2:
            slaveName = info[1] #id
            slave = self.slaves.findSlave (slaveName)
            if slave == None: 
               command = info[2]
               if (command == 'Hello'): #Response to Hello command
                  # print 'I recognize this slave type:' + typeName + ' adding it to list'
                  self.slaves.addSlave (slaveName, self.sock)        
                  slave = self.slaves.findSlave (slaveName)
                  slave.setState (info[3])
                  self.gui.addSlave (slave) # This should select the slave  
                  if (len(info) > 4):                  
                    self.gui.setDeviceType ( info [4] )
                  else:              
                    print 'Error, type info not provided'                  
               else:   
                  print 'Err...I do not recognize this command: ' + command
            else:
               response = info[2] 
               print 'Found the slave, got this response: ' + response
               if response == 'whatTime': # Slave is giving its current RTC time
                  self.gui.setActualTime ( info[3], info[4] )
                  if len(info) > 5:
                     self.gui.setActualDay (info[5])
                  else:
                     print 'ERROR did not receive any day information'                  
               elif response == 'Available': # Slave is available
                  slave.setState ('Available')
                  self.gui.showSlaves()                        
               elif response == 'State': # Slave is giving state information  
                  slave.setState (info[3]) 
                  self.gui.showSlaves()
               elif response.find ('Times') > -1: # Slave is giving times
                  relay = int (response[5:])
                  self.gui.setStartTime ( relay, info[3], info[4] ) 
                  self.gui.setEndTime ( relay, info[5], info[6] )               
               elif response.find ('timerName') > -1: # Slave is name for each timer
                  relay = int (info[3])
                  print 'Getting name for relay: ' + str(relay)
                  self.gui.setTimerName ( relay, info[4] )
               elif response == 'readDeviceType':
                  print 'Got back a readDeviceType command from the UUT'
                  self.gui.setDeviceType ( info [3] )
               elif response == 'readResponseIndex':
                  print 'Got back a readResponseIndex command from the UUT'
                  self.gui.setResponseIndex ( info[3] )                  
               elif response == 'ACK':
                  print '****Got**** an ACK!'
               elif response == 'NAK':
                  print '***ERR*** got a NAK!'                        
               else:
                  print 'Unexpected response from slave: ' + response                                  
      else:
         # print 'Not for me: ' + response
         canHandle = False
         
      return canHandle
         
   def getResponse (self,seconds):
      gotResponse = False
      startTime = time.time()
      # give time for slave to listen
      while time.time() < startTime + seconds:
         info = self.checkResponse()
         if info != None:
            if self.canHandleResponse (info):
               gotResponse = True
               break
      return gotResponse      


class GUI (Tkinter.Tk):
   def __init__ (self,slaves):
      Tkinter.Tk.__init__(self, None)         
      self.slaves = slaves
      self.sprinkler = False
      self.waterBox = False
      self.remember = Remember.Remember()
      
   def handleClose(self):
      print 'I got a window close event'    
      
   def onListBoxSelect (self,event):
      print 'Number of items: ' + str(self.listbox.size())
      if self.listbox.size() == 0:
         print 'list is empty' 
      else:
         selection = self.listbox.curselection()
         sel = self.listbox.get(selection[0])
         name = sel.split(' ')[0]
         print name + ' selected'
         firstName = name.split ( ':' )
         slave = self.selectedSlave()
         if (slave.typeNumber == 0) or (slave.typeNumber == 1): 
            self.slave = slave            
            self.sprinkler_box()
            self.timerDeviceId = name            
         elif (slave.typeNumber == 2):
            self.slave = slave
            self.waterSensorBox()            
         else:
            print 'sprinkler_box() not called because typeNumber: ' + str (slave.typeNumber)               
               
   def currentDay (self):
      day = int (time.strftime ( "%w", time.localtime () )) 
      days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday' ]
      return days[day]
      
   def updateUtcTime (self):
      os.system ( 'sudo date -s \'' + self.utcTime.get() + '\'' )   
 
   def initialize (self):      
      # Main Frame
      print 'Getting the comm class' 
      self.communicationsClass = CommunicationsClass(self.slaves, self)
      self.slaves.setCommClass ( self.communicationsClass )
            
      self.frame = Tkinter.Frame (self)            
      self.frame.pack (side=Tkinter.LEFT)
      self.top = self.frame
      
      frame = Tkinter.Frame(self.frame)
      frame.pack (side=Tkinter.TOP)
      self.utcTime = Tkinter.StringVar()
      entry = Tkinter.Entry (frame, width=28, textvariable=self.utcTime)
      entry.pack (side=Tkinter.LEFT)      
      self.utcTime.set ( time.strftime ( "%a %b %d %H:%M:%S UTC %Y", time.localtime ()) )

      button = Tkinter.Button (frame, text=u"Update Internal Clock",command=self.updateUtcTime)
      button.pack (side=Tkinter.LEFT)     
      
      frame = Tkinter.Frame(self.frame)
      frame.pack (side=Tkinter.TOP)
      label = Tkinter.Label (frame, text="Current Time")
      label.pack (side=Tkinter.TOP)
      label = Tkinter.Label (frame, text="Day")
      label.pack (side=Tkinter.LEFT)
      label = Tkinter.Label (frame, text="Hours")
      label.pack (side=Tkinter.LEFT)
      label = Tkinter.Label (frame, text="Minutes" )
      label.pack (side=Tkinter.LEFT)
      frame = Tkinter.Frame (self.frame)
      frame.pack (side=Tkinter.TOP)

      self.dayOfWeek = Tkinter.StringVar()
      label = Tkinter.Label (frame, textvariable = self.dayOfWeek)
      self.dayOfWeek.set ( self.currentDay() )
      label.pack (side=Tkinter.LEFT)
      self.hours = Tkinter.StringVar()
      entry = Tkinter.Entry (frame, width=7, textvariable=self.hours)
      entry.pack (side=Tkinter.LEFT)
      self.minutes = Tkinter.StringVar()
      entry = Tkinter.Entry (frame, width=7, textvariable=self.minutes)
      entry.pack (side=Tkinter.LEFT)
      frame = Tkinter.Frame (self.frame)
      frame.pack (side=Tkinter.TOP)
      button = Tkinter.Button (frame, text=u"Send RTC",command=self.UpdateCurrentTime)
      button.pack (side=Tkinter.LEFT)
      
      frameA = Tkinter.Frame(self.frame)
      frameA.pack (side=Tkinter.TOP)
      
      frame1 = Tkinter.Frame(frameA)
      frame1.pack (side=Tkinter.LEFT)
      self.label = Tkinter.Label (frame1,text="Available Devices")  
      self.label.pack (side=Tkinter.TOP)
      self.listbox = Tkinter.Listbox (frame1,width=50)
      self.listbox.bind('<<ListboxSelect>>', self.onListBoxSelect)       
      self.listbox.pack (side=Tkinter.TOP)
      
      if DEBUGIT:
         self.communicationsClass.addTestSlave()     
               
      slaveCmdFrame = Tkinter.Frame(frameA)      
      slaveCmdFrame.pack(side=Tkinter.LEFT)
      self.turnOn = Tkinter.Button (slaveCmdFrame, text=u"On",width=10,command=self.TurnOn)
      self.turnOn.pack (side=Tkinter.LEFT)
      self.turnOff = Tkinter.Button (slaveCmdFrame, text=u"Off",width=10,command=self.TurnOff)
      self.turnOff.pack (side=Tkinter.LEFT)
      button = Tkinter.Button (slaveCmdFrame, text=u"RTC",command=self.RTC)
      button.pack (side=Tkinter.LEFT)               
      
      frame = Tkinter.Frame (self.frame)  
      frame.pack (side=Tkinter.TOP)      
      self.times = []
         
      timerFrame3 = Tkinter.Frame (self.frame)  
      timerFrame3.pack (side=Tkinter.TOP)      
      self.poll = Tkinter.Button(timerFrame3,text=u"Poll",width=18,command=self.pollForSlaves)
      self.poll.pack (side=Tkinter.LEFT)
      self.status = Tkinter.Button (timerFrame3, text=u"Status",width=16,command=self.Status)
      self.status.pack (side=Tkinter.LEFT)
      button = Tkinter.Button (timerFrame3, text=u"Show Water Sensor",width=16,command=self.showWaterSensor)
      button.pack (side=Tkinter.LEFT)
      
      hours = int (time.strftime ("%H", time.localtime()))
      minutes = int (time.strftime ( "%M", time.localtime ()))
      self.setActualTime (hours, minutes) 
      
      self.clock = ClockClass(self.remember,self)
      self.clock.start()
      
      
   def waterSensorBox (self):
      print ''
      print '***water_sensor_box called*****'
      print ''
      if self.waterBox:
         print 'Only 1 water sensor box allowed'
      else:
         self.waterBox = True
         slave = self.selectedSlave()         
         w = WaterSensor.WaterSensor (self,slave,self.remember)
         w.setStatus ( 1, 'All good with 1' )
       
       
   def sprinkler_box(self):
      print ''
      print '****sprinkler_box  called*****'
      print ''
      days = ['Su', 'Mo','Tu','We','Th','Fr','Sa']
      if self.sprinkler:
         print 'Only 1 timer box allowed'
      else:
         slave = self.selectedSlave()
         t = Sprinkler.Sprinkler (self, slave, self.remember,handler)
         self.sprinkler = True
         self.tBox = t

   def namePress (self, event, timer):
      print 'namePress: '
      print timer
      slave = self.selectedSlave()
      index = int(timer)
      name = self.timerNames[index].get()
      #cmd ='writeTimerName' + str (index) + ' ' + name
      #self.SendCommand (self.slave, cmd )
      self.remember.names[index] = name
      self.SelectSlave (slave)
           
   def UpdateCurrentTime (self):
      print self.hours.get() + ':' + self.minutes.get() 
      
      day = int (time.strftime ( "%w", time.localtime () )) 
      
      message = 'RTC' + self.hours.get() + ' ' + self.minutes.get() + ' ' + str(day)
      self.communicationsClass.sendto (message, False)      
      
   def setIpAddress (self,ipAddress):
      self.myIpAddress.set (ipAddress )
      print 'setIpAddress: ' + ipAddress
      
   def setTimerName ( self, relay, name):
      print 'setTimerName, Relay ' + str (relay) + ' name: ' + name
      if self.timerNames[int(relay)] == None:
         print 'Err...self.timerNames == None'
      else:   
         self.timerNames[int(relay)].set (name)

   def setActualTime (self, hours, minutes):
      self.hours.set ( str (hours) )
      self.minutes.set ( str (minutes) )
      
   def setActualDay (self, day):
      days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday' ]
      self.dayOfWeek.set ( days[int(day)] )
      
   def setResponseIndex (self, responseIndex):
      print 'setResponseIndex called'   
      self.responseIndex.set ( str ( responseIndex ) )
      
   def packLabels (self, labels ):
      frame = Tkinter.Frame (self.frame)
      frame.pack (side=Tkinter.TOP)
      for value in labels:
         label = Tkinter.Label (frame, text = value)
         label.pack (side=Tkinter.LEFT)
      return frame    

   def packStartEndTime (self, array, numItems ):
      frame = Tkinter.Frame (self.frame)
      frame.pack (side=Tkinter.TOP);
      for i in range (numItems):
         startTime = Tkinter.Entry (frame, width=7)
         startTime.pack (side=Tkinter.LEFT)
         endTime = Tkinter.Entry (frame, width=7)
         endTime.pack (side=Tkinter.LEFT)
         label = Tkinter.Label (frame, text = "             " )
         label.pack (side=Tkinter.LEFT)
         array.append ( (startTime,endTime) )
         
   def appendStatusFile ( self, line ):
      try:
         f = open ( 'status.txt','a' )
         f.write ( self.clock.currTime() + ' ' + line + '\n')
         f.close ()
      except:
         pass      
   
   def turnTimer(self,deviceId,timer,on):
      relay = int (timer) - 1 # Arduino is zero based
      print 'Turn on Timer' + str(relay)       
      if on:
         self.SendNameCommand (deviceId, 'relayon' + str(relay))  
         self.appendStatusFile ( 'Turn timer ' + str (timer) + ' on' )
      else:
         self.SendNameCommand (deviceId, 'relayoff' + str(relay))      
         self.appendStatusFile ( 'Turn timer ' + str (timer) + ' off' )
         
      info = self.communicationsClass.checkResponse()
      if info != None:
         if (info[0] == 'Master'):
            if (info[2] == 'ACK' ):
               self.appendStatusFile ( 'Got an ACK')
            elif (info[2] == 'NAK'):
               self.appendStatusFile ( 'Got a NAK')
            elif (info[2] != None ):
               self.appendStatusFile ( 'Not sure what I got: ' + info[2] )                       
               
   def RTC (self):
      hours = int (time.strftime ("%H", time.localtime()))
      minutes = int (time.strftime ( "%M", time.localtime ()))
      day = int (time.strftime ( "%w", time.localtime () )) 
      rtcCommand = 'RTC' + str(hours) + ' ' + str(minutes) + ' ' + str(day)
      slave = self.selectedSlave()
      if slave:
         self.communicationsClass.sendto (rtcCommand, False)
         self.SelectSlave (slave)
      else:
         print 'You must select a slave first'
         
   def setDeviceType ( self, deviceType ):
      print 'setDeviceType (' + deviceType + ')'
      curSlave = self.selectedSlave ()
      curSlave.setDeviceType ( int (deviceType) )
      self.showSlaves()
      
   def showSlaves(self): 
      curSlave = self.selectedSlave ()
      self.listbox.delete (0, Tkinter.END )     
      for slave in self.slaves.slaves:
         self.listbox.insert ( Tkinter.END, slave.name + ' ' + slave.typeName + ' ' + slave.state) 
         self.SelectSlave (slave)             
      
   def addSlave (self, slave):
      # Show all slaves, the slave has already been added ?!where?!
      self.showSlaves()
      self.SelectSlave (slave) # select the added slave
      
   def pollForSlaves (self):       
      if self.communicationsClass == None:
         print 'Initializing communicationsclass'
         self.communicationsClass = CommunicationsClass(self.slaves, self)
      
      self.communicationsClass.sendHello()            
      self.poll.configure(bg='green', text=u"Poll")

   def onquit (self, reason):
      print 'onquit...reason: ' + str (reason)
      try: 
         self.communicationsClass.stopThread = True
         print 'communicationClass.stopThread is set True'
      except:
         print 'communicationsClass has not been created yet'
      self.clock.done = True   

   def SelectSlave (self,slave):
      if (slave != None):
         listboxList = []
         for i in range (self.listbox.size()):
            item = self.listbox.get(i)
            items = item.split ( ' ' )
            listboxList.append (items[0] )
         print listboxList
      
         count = 0     
         for s in listboxList:
            if s == slave.name:
               self.listbox.selection_set(count,True)
               print 'Found slave, select: ' + str (count)
               break
            else:
               print s + ' != ' + slave.name          
            count = count + 1
         
   def selectedSlave(self):
      selection = self.listbox.curselection()
      if not selection:
         slave = None
      else:
         sel = self.listbox.get(selection[0])
         name = sel.split(' ')[0]
         slave = self.slaves.findSlave(name)
      return slave

   def SendNameCommand (self,name,command):
      self.communicationsClass.sendNameCommand (name,command)   
      
   # Destination will be prepended to command      
   def SendCommand (self,slave,command):
      if slave:
         self.communicationsClass.sendCommand (slave, command)      
         self.SelectSlave (slave)
      else:
         print 'You must select a slave first'
               
   def Command(self):
      slave = self.selectedSlave()
      if slave:
         self.SendCommand (slave,raw_input ('Enter command for slave:' ))
      else:
         print 'You must select a slave first'
         
   def TurnOn (self):
      slave = self.selectedSlave()
      self.SendCommand(slave, 'Turn on' )
      self.SelectSlave(slave)
      
   def TurnOff (self):
      self.SendCommand(self.selectedSlave(), 'Turn off' )
      
   def Timer (self):
      self.SendCommand (self.selectedSlave(), 'Timer' + self.seconds.get())   

   def showWaterSensor (self):
      slave = self.selectedSlave()
      self.waterSensorBox()
      
   def Status (self):
      slave = self.selectedSlave()
      if slave == None:
         print 'No slave is yet selected'
      else:
         self.SendCommand (slave, '?' ) 
         self.SendCommand (slave, 'whatTime') 
         self.SendCommand (slave, 'readDeviceType')
        
'''
   ClockClass creates a thread that runs once a seconds and 
   checks the clock time.  
   If the minute has changed it will check timer start and end times.
   This class if then only used for the irrigation class.
'''
class ClockClass(threading.Thread):
   def __init__ (self,remember,gui):
      threading.Thread.__init__(self)
      self.remember = remember
      self.gui = gui
      self.mail = MailMe()

   def currTime (self):
      currTime = time.strftime ("%H%M", time.localtime())
      return currTime
           
   def stopThread (self):
      self.done = True
                  
   def run(self):
      self.done = False
      print self.currTime ()
      lastTime = ""
      count = 0
      debugIt = False
      communicationsClass = self.gui.communicationsClass
      lastIpAddress = ''
      while not self.done:
         if self.currTime() != lastTime: # A new minute has transpired
            if lastIpAddress != getIpAddress():
               text = 'Raspberry pi controller is now at this ip address: ' + getIpAddress() 
               self.mail.sendMail ( 'New IpAddress', text )
               lastIpAddress = getIpAddress()
               
            if (int(self.currTime()) == 0):            
               text = 'From pi at: ' + getIpAddress()
               try:
                  f = open ('status.txt','r') # open for read
                  lines = f.readlines()
                  f.close()
               
                  for line in lines:
                     text = text + '\n' + line
               except:
                  pass
                     
               self.mail.sendMail ( 'Daily status', text )      
               #reboot at midnight
               #TODO send a shutdown message to all devices
               os.popen ( 'sudo shutdown -r now')
               
               f = open ('status.txt','w') # clear out the old file
               f.close()
            if count == 0:
               sys.stdout.write ( self.currTime() ) 
            elif count == 9:
               print (',' + self.currTime() )
            else:
               sys.stdout.write ( ',' + self.currTime() )
               
            count = count + 1
            count = count % 10
            lastTime = self.currTime()  
            for i in range (len(self.remember.startAt)):
               if self.remember.startAt[i] == int(self.currTime()):
                  self.gui.turnTimer(self.gui.timerDeviceId, i+1, True)                     
               elif self.remember.endAt[i] == int(self.currTime()):
                  self.appendStatusFile ( 'Turn timer ' + str (i+1) + ' off' )
                  self.gui.turnTimer(self.gui.timerDeviceId, i+1, False)         
         time.sleep (1.0)  
         
def handler():
   print 'got a window handler close' 
   app.tBox.toplevel.destroy()
   app.sprinkler = False
   
if __name__ == "__main__":
   slaves = Slaves()      
   print 'Create the GUI app'   
   app = GUI (slaves) 
   app.initialize()   
   app.title ('Python Sensor Network')
   print 'Go to main loop'
   app.bind ("<Destroy>",app.onquit)
   
   app.mainloop()  
