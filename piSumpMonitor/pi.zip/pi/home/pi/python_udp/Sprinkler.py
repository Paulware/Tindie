#Master.py

'''
   Each gui will have its own communications class will send commands and expect 
   responses.  
   The slave object will not need to be known at the gui level, as all information 
   will be passed that is neccessary to sent to device.
'''


import socket
import time
import Tkinter 
import threading
import ttk
import Remember
import os

class Sprinkler ():
   def close_window(self):
      print 'Frame is now closing'
      
   def __init__ (self,gui,slave,remember,handler):      
      self.handler = handler
      self.name = slave.name
      self.gui = gui
      self.remember = remember
      self.communicationsClass = slave.commClass
      self.slave = slave
      self.startTimeVariables = [None,None,None,None,None,None,None,None]
      self.endTimeVariables   = [None,None,None,None,None,None,None,None]
      self.timerNames         = [None,None,None,None,None,None,None,None]
          
      self.toplevel = Tkinter.Toplevel()    
      frame = Tkinter.Frame (self.toplevel)
      #frame.close_window = self.close_window

      self.toplevel.protocol ( 'WM_DELETE_WINDOW', self.handler )
      # self.toplevel.protocol ( 'WM_DELETE_WINDOW',self.onClose )
      frame.pack (side=Tkinter.TOP)
      self.top = frame
      
      deviceIdFrame = Tkinter.Frame (frame)
      deviceIdFrame.pack (side=Tkinter.TOP)
      label = Tkinter.Label (deviceIdFrame, text='Device Id:')
      label.pack (side=Tkinter.LEFT)   
      self.myId = Tkinter.StringVar()         
      entry = Tkinter.Entry ( deviceIdFrame, textvariable=self.myId)
      entry.bind('<KeyRelease>', self.deviceIdPress)
      entry.pack(side=Tkinter.LEFT)         
      self.reversePin = Tkinter.StringVar()  
      label = Tkinter.Label (deviceIdFrame, text='IP Address')
      label.pack (side=Tkinter.LEFT)
      self.myIpAddress = Tkinter.StringVar()
      entry = Tkinter.Entry ( deviceIdFrame, textvariable =self.myIpAddress)
      entry.bind ( '<KeyRelease>', self.ipAddressPress)
      entry.pack(side=Tkinter.LEFT)   
      checkbox = Tkinter.Checkbutton (deviceIdFrame, text='reverse pin', variable = self.reversePin, 
                                      onvalue='checked', offvalue='unchecked', command=self.reverseCb)
      checkbox.pack (side=Tkinter.LEFT)         
      label = Tkinter.Label (deviceIdFrame, text='Response Index')
      label.pack (side=Tkinter.LEFT)
      self.responseIndex = Tkinter.StringVar()
      entry = Tkinter.Entry ( deviceIdFrame, textvariable=self.responseIndex)
      entry.pack(side=Tkinter.LEFT)
      entry.bind('<KeyRelease>', self.responseIndexPress)              
      button = Tkinter.Button (deviceIdFrame, text=u"Save", command=self.saveTimerBox)
      button.pack (side=Tkinter.TOP)               
               
      self.dayValues = []
      timersPart1 = Tkinter.Frame (self.top)
      timersPart1.pack (side=Tkinter.TOP)         
      
      for timer in range(8):
         print ''
         print '****Timer' + str (timer) + '****'
         print ''
         if timer == 4:
            timersPart1 = Tkinter.Frame (self.top)
            timersPart1.pack (side=Tkinter.TOP)          
         frame = Tkinter.Frame (timersPart1)
         frame.pack (side=Tkinter.LEFT)         
         self.timerNames[timer] = Tkinter.StringVar()         
         self.startTimeVariables[timer] = Tkinter.StringVar()
         self.startTimeVariables[timer].set (self.remember.startAt[timer] )
         self.endTimeVariables[timer] = Tkinter.StringVar()
         self.endTimeVariables[timer].set (self.remember.endAt[timer] )
            
         entry = Tkinter.Entry ( frame, textvariable=self.timerNames[timer])
         entry.bind('<KeyRelease>', lambda event,m=timer: self.namePress(event,m))
         self.timerNames[timer].set ( self.remember.names[timer] )
            
         entry.pack(side=Tkinter.TOP)         
         
         onOffFrame = Tkinter.Frame (frame)
         onOffFrame.pack (side=Tkinter.TOP)
         button = Tkinter.Button (onOffFrame, text=u"On",command=lambda m=timer:self.onTimerPress(m+1))
         button.pack (side=Tkinter.LEFT)               
         button = Tkinter.Button (onOffFrame, text=u"Off",command=lambda m=timer:self.offTimerPress(m+1))
         button.pack (side=Tkinter.LEFT) 
            
         startEndFrame = Tkinter.Frame (frame)
         startEndFrame.pack (side=Tkinter.TOP)
         label = Tkinter.Label ( startEndFrame, text='  Start Time    End Time ')
         label.pack (side=Tkinter.TOP)   
         label = Tkinter.Label (startEndFrame, text= '   ' )
         label.pack (side=Tkinter.LEFT)
         entry = Tkinter.Entry (startEndFrame, width=7, textvariable=self.startTimeVariables[timer])
         entry.bind('<KeyRelease>', lambda event,m=timer: self.keyPressStart(event,m))     
         entry.pack (side=Tkinter.LEFT)
         label = Tkinter.Label (startEndFrame, text= '   ' )
         label.pack (side=Tkinter.LEFT)
         timeEntry = Tkinter.StringVar()
         entry = Tkinter.Entry (startEndFrame, width=7, textvariable=self.endTimeVariables[timer])
         entry.bind('<KeyRelease>', lambda event,m=timer: self.keyPressEnd(event,m))
         entry.pack (side=Tkinter.LEFT)
         self.timerSlave = self.slave
         #self.top = self.gui.top
         self.top.bind ("<Destroy>",self.timerExit)
            
         dayFrame1 = Tkinter.Frame (frame)
         dayFrame1.pack (side=Tkinter.TOP)
         label = Tkinter.Label ( dayFrame1, text=' Days ')
         label.pack (side=Tkinter.TOP)
         count = 0
         week = []
         for day in range(7):
           week.append (Tkinter.StringVar())
         self.dayValues.append (week)  
         for day in ['Su','Mo','Tu','We']:
            checkbox = Tkinter.Checkbutton (dayFrame1, text=day, variable = week[count], 
                                            onvalue='checked', offvalue='unchecked',
                                            command=lambda t=timer,s=week:self.writeDay (t,s))
            checkbox.pack (side=Tkinter.LEFT)
            count = count + 1
               
         dayFrame2 = Tkinter.Frame (frame)
         dayFrame2.pack (side=Tkinter.TOP)
         label.pack (side=Tkinter.TOP)               
         for day in ['Th','Fr','Sa']:
            checkbox = Tkinter.Checkbutton (dayFrame2, text=day, variable = week[count], 
                                            onvalue='checked', offvalue='unchecked',
                                            command=lambda t=timer,s=week:self.writeDay (t,s))
            checkbox.pack (side=Tkinter.LEFT)
            count = count + 1
            
               
      self.getTimeBoxInfo() 

   def SendCommand (self,command):
      message = self.name + ':' + command + chr(0)
      self.communicationsClass.sockSendTo (message)          

   def setReverse (self,checked):
      print 'reversePin set to ' + checked
      self.reversePin.set (checked)   

   def reverseCb (self):
      reverse = self.reversePin.get()
      print 'Got a reverse Cb click: ' + reverse
      self.SendCommand ('reverse' + reverse) 
         
   '''
      Remember class will have start and end times, timer names and selected days
   '''
   def getTimeBoxInfo (self):
      # Get timers
      for i in range(8):
         print 'daysOfWeek[' + str(i) + ']: ' + str (self.remember.daysOfWeek[i])
         self.setReadDays (i,self.remember.daysOfWeek[i])
         
      # get Reverse
      self.SendCommand ('readReverse' )
      self.handleResponse('readReverse')

      # get Device Id
      self.SendCommand ('readDeviceId' )      
      self.handleResponse('readDeviceId')
     
      self.SendCommand ('readIpAddress')
      self.handleResponse('readIpAddress')
      
      self.SendCommand ('readResponseIndex')
      self.handleResponse('readResponseIndex')
      
   def handleResponse(self, response):
      # give time for slave to listen
      startTime = time.time()
      seconds = 3     
      while time.time() < startTime + seconds:
         info = self.communicationsClass.checkResponse()  
         if info != None:         
            if info[0] == 'Master': # This is for me
               print 'info: ' + str(info)
               if info[2] == response:
                  if response == 'readReverse':
                     self.setReverse (info[3])
                  elif response == 'readDeviceId':
                     self.myId.set(info[3])
                  elif response == 'readIpAddress':
                     ipAddress = ''
                     for bytes in info[3:]:
                        if ipAddress == '':
                           ipAddress = bytes
                        else:
                           ipAddress = ipAddress + '.' + bytes                        
                     self.myIpAddress.set(ipAddress)
                  elif response == 'readResponseIndex':
                     self.responseIndex.set (info[3])                     
                  break
               else:
                  print 'handleResponse confused by: ' + info[2]            
                     
   def writeDay (self,timer,values):
      total = 0
      for i in range(len(values)):
         total = total * 2
         if values[i].get() == 'checked':
            total = total + 1
      cmd = 'writeDays' + str(timer) + ' ' + str(total)
      print cmd
      self.SendCommand (cmd )
      self.remember.daysOfWeek[timer] = total
      
   def timerExit (self, event):
      self.timerBox = False
      
   def saveTimerBox (self):
      self.remember.save()  
         
   def keyPressStart (self, event, timer):
      index = int(timer)
      value = self.startTimeVariables[index].get()
      cmd ='startTime' + str (index) + ' ' + self.getHoursMinutes(value)
      print cmd
      self.SendCommand (cmd )
      self.remember.startAt [index] = int (value)
      
   def keyPressEnd (self,event,timer):
      index = int(timer)
      value = self.endTimeVariables[index].get()
      cmd ='endTime' + str (index) + ' ' + self.getHoursMinutes(value)
      print cmd
      self.SendCommand (cmd )
      self.remember.endAt [index] = int (value)

   def getHoursMinutes ( self,value ):
      try:
        total = int (value)
      except:
        total = 0
      hours = total / 100
      minutes = total % 100
      message = ''
      if hours < 10:
        message = '0'
      message += str(hours)
      if minutes < 10:
        message += '0'
      message += str(minutes)
      return message
      
   def deviceIdPress (self, event):
      name = self.myId.get()
      if name != '':
         cmd = 'writeDeviceId' + name
         print cmd
         self.SendCommand (cmd)      
         self.renameId ( self.slave.name, name)
         self.name = name
         self.slave.name = name #TODO: make sure upper level gui is updated
            
   def ipAddressPress (self,event):
      ipAddress = self.myIpAddress.get()
      cmd = 'writeIpAddress' + ipAddress
      # print cmd
      self.SendCommand (cmd)
      
   def responseIndexPress (self, event):      
      responseIndex = self.responseIndex.get()
      cmd = 'writeResponseIndex ' + responseIndex
      self.SendCommand (cmd)
      
   def offTimerPress(self,name):
      relay = int (name) - 1 # Arduino is zero based
      self.gui.turnTimer ( self.name, int(name), False )
      #print 'Turn off Timer' + str(relay) 
      #self.SendCommand ('relayoff' + str(relay))   
      
   def onTimerPress(self,name):
      relay = int (name) - 1 # Arduino is zero based
      #print 'Turn on Timer' + str(relay) 
      #self.SendCommand ('relayon' + str(relay))  
      self.gui.turnTimer (self.name, int(name), True )      

   def setReadDays ( self, relay, days ):
      values = [64,32,16,8,4,2,1]
      d = int(days)
      print 'week: ' + str (relay) + ' days: ' + str(days)   
      print 'timer: ' + str(relay) 
      week = self.dayValues[int(relay)]
    
      for i in range(7):
         if (d & values[i]) > 0:
           print 'setting ' + str(i) + ' to checked ' + str(d) + ' & ' + str(values[i]) + ' > 0'
           week[i].set ('checked')
         else:
           week[i].set ( 'unchecked')      
      
   def setStartTime ( self, relay, hours, minutes):
      newValue = ''
      if (int(hours) < 10):
        newValue = '0'
      newValue += str(hours)
      if (int (minutes) < 10):
        newValue += '0'
      newValue += str(minutes)        
      print 'setStartTime, Relay ' + str (relay) + ' start time: ' + newValue
      if self.startTimeVariables[int(relay)] == None:
         print 'ERR startTimeVariables is not set?!'
      else:
         self.startTimeVariables[int(relay)].set (newValue)       
      
   def setEndTime ( self, relay, hours, minutes):
      newValue = ''
      if (int(hours) < 10):
        newValue = '0'
      newValue += str(hours)
      if (int (minutes) < 10):
        newValue += '0'
      newValue += str(minutes)        
      print 'setEndTime, Relay ' + str (relay) + ' start time: ' + newValue
      if self.endTimeVariables[int(relay)] == None:
         print 'Error endTimeVariables is set to None'
      else: 
         self.endTimeVariables[int(relay)].set (newValue)    

   def renameId ( self, oldName, newName ):
      print 'Search for this name in the list: ' + oldName + ' replace it with this name: ' + newName
      self.gui.slaves.renameSlave (oldName,newName)
      self.gui.showSlaves()
      
        

