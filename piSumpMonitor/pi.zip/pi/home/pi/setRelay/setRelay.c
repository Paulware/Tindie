#include <wiringPi.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#define DEBUGIT 1

void write_val (int pin, int value)
{
  
  pinMode(pin,OUTPUT);
  if (value)
  {
    digitalWrite (pin,HIGH);
    if (DEBUGIT)
      printf ( "Wrote pin %d HIGH\n", pin );    
  }  
  else
  {
    digitalWrite(pin,LOW);
    if (DEBUGIT)
      printf ( "Wrote pin %d LOW\n", pin );
  }  
}
int main(int argc, char *argv[])
{
  int pin = -1;
  int returnValue = 0;
  int offOn = -1;
  char *data;

  printf ("Content-type: text/html\n\n");
  printf ("<html><body>");
  
  /*
  data = getenv ("QUERY_STRING");
  if (data == NULL)
    printf ("Error! Error in passing data from form to script.");
  else if (sscanf(data,"pin=%ld&value=%ld",&pin,&value) != 2)
    printf ("Error! Invalid data.  Data must be numeric." );
  else
  {  
  */
    
     
    if (!strcmp (argv[1], "gpio17"))
      pin = 0;
    else if (!strcmp (argv[1], "gpio18"))
      pin = 1;
    else if ( (!strcmp (argv[1], "gpio21")) || (!strcmp (argv[1], "gpio27")))
      pin = 2;    
    else if (!strcmp (argv[1], "gpio22"))
      pin = 3;
    else if (!strcmp (argv[1], "gpio23"))
      pin = 4;
    else if (!strcmp (argv[1], "gpio24"))
      pin = 5;
    else if (!strcmp (argv[1], "gpio25"))
      pin = 6;    
    else if (!strcmp (argv[1], "gpio4"))
      pin = 7;
    else
      printf ( "gpio should be gpio17, gpio18, gpio21, gpio22, gpio23, gpio24, gpio25 or gpio4" ); 
     
    if (!strcmp (argv[2], "1"))
      offOn = 1;    
    else if (!strcmp (argv[2], "0"))
      offOn = 0;
    else
      printf ( "offOn value should be 1 or 0\n" );

    // printf ("Set pin %d = %d.\n",pin,offOn);
    if(wiringPiSetup()==-1)
    {
      printf ( "Could not setup wiring\n" );
      returnValue = 1;
    }  
    else
    {
      write_val(pin, offOn);
    }
      
  printf ("</html></body>\n");
  return returnValue;  
}
