<?php
  $user = $_COOKIE["user"]; 
?>

<html>
<head> <Title>Add Sensor</Title>

<script>
  <?php
     print ( '  var user=\'$user\';');
  ?>
  function addSensor (value) {
    window.location.href = 'addSensorMac.php?mac=' + value;
  }

</script>

</head>

<body>
Sensor's MAC Address:<input name="macAddress">
         <input type=button value="Add" onclick="javascript:addSensor(document.all.macAddress.value);">
</body>
</html>