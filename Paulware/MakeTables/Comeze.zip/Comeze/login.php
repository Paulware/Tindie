<?php
  $user = $_GET["user"];
  if ($user != "") 
  {
    setcookie ("user", "$user", time()+36000);
    header( 'Location: index.php' );
  }
?>

<html>
<head> <Title>Login Please</Title>

<script>


  function login (value) {
    var user = document.all.user.value;
    var password = document.all.password.value;
    window.location.href = 'requestLogin.php?user=' + user + '&password=' + password;
  }

</script>

</head>

<body>
<table>
<tr><td>User Name</td><td><input name="user"></td></tr>
<tr><td>Password</td><td><input name="password"></td></tr>
</table><hr>
<input type=button value="Login" onclick="javascript:login(document.all.user.value);">
</body>
</html>