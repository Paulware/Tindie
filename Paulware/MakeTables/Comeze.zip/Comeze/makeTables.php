<html>
<body>
Creating tables
<?php 
  include "common.inc";
  $q = mysql_query ("Drop Table Sensors");
  $sql = "CREATE TABLE Sensors (ID INT NOT NULL AUTO_INCREMENT PRIMARY KEY, MAC char(255), Value char(255))";
  $result = query ($sql);
  $q = mysql_query ("Drop Table Users");
  $sql = "CREATE TABLE Users (ID INT NOT NULL AUTO_INCREMENT PRIMARY KEY, Username char(255), Password char(255))";
  $result = query ($sql);
  $q = mysql_query ("Drop Table Users");
  $sql = "CREATE TABLE Users (ID INT NOT NULL AUTO_INCREMENT PRIMARY KEY, User INT NOT NULL, Sensor INT NOT NULL)";
  $result = query ($sql);
  echo ("Tables created.");
?>
</body>
</html>