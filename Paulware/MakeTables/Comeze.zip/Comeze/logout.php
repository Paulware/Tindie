<?php
    setcookie("user", "", time()-3600);
?>

<html>
<head> <Title>Logging out</Title>

<script>

    window.location.href = 'index.php';


</script>

</head>

<body>
</body>
</html>