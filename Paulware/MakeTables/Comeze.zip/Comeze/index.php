<html>
<head>
<title>Home Automation</title>
<Script>
  <?php
  $user = $_COOKIE["user"]; 
  echo ( "   var User='$user';\n")
  ?>
  function deleteSensor(MAC) {
     window.location.href = 'deleteOwner.php?User=' + User + '&MAC=' + MAC;     
  }
</Script>
</head>
<body>
<p><center style="font-size:200%">Welcome to Comeze Home Automation Center</center></p>
<?php
  if ($user != "") {
     print ("<H1>Welcome $user</H1><br>\n"); 
     print ("<input type=\"button\" value=\"Logout\" onclick=\"location.href='logout.php';\"><br>\n");
     print ("<input type=\"button\" value=\"Add Sensor\" onclick=\"location.href='addSensor.php';\"><br>\n");
  } else {
     print ("<input type=\"button\" value=\"Login\" onclick=\"location.href='login.php';\"><br>\n");
  }
?>
View and control sensors<br>
<h1>Things to do </h1>
<hr>
<ul>
<li>Delete Sensors<input type="checkbox"></li>
<li>Modify Sensor Types<input type="checkbox"></li>
<li>Output based on sensor type<input type="checkbox"></li>
<li>Sensor values trigger email<input type="checkbox"></li>
<table border="2px solid">
<tr><th>MAC</th><th>Value</th><th>Timestamp</th><th>Delete</th></tr>
<?php
   include "common.inc";
   include "common.php";
   $id = findUser($user);
   if ($id) {
     $userId = $id['ID'];
     $sql = "Select * From Owners Where User=$userId";

     $result = query ( "Select * From Owners Where User=$userId" );
     while ($row = mysql_fetch_assoc ($result)) 
     {
       $sensorId = $row['Sensor'];
       $sensor = findSensorId ($sensorId);

       $MAC = $sensor["MAC"];
       $Value = $sensor["Value"];
       $Timestamp = $sensor["Timestamp"];
       print ("<tr><td>$MAC</td><td>$Value</td><td>$Timestamp</td><td><input type=\"button\" value=\"go\" onclick=\"deleteSensor('$MAC');\"></tr>");
     }
    }    
?>
</table>
</body>
</html>
